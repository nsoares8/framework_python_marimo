import decimal
import numbers
from collections.abc import Iterable
from typing import Any
from .encoding import checkInvalidCaracter
from .exception import InvalidParameterException


def check_names(*names: Any) -> None:
    """Raise InvalidParameterException if any table, column or partition name is not a valid Oracle name."""
    for name in names:
        if not isinstance(name, str) or not checkInvalidCaracter(name):
            raise InvalidParameterException(f"Invalid name: {name!r}")


def as_list(value: Any, name: str, *, strings_only: bool = True) -> list | None:
    """
    Normalise a parameter that takes a list of names or SQL expressions.
    None or "" -> None (each method keeps its default); a string -> [string];
    an ordered collection (list, tuple, pandas Index/Series, numpy array) -> list.
    A set or a dict (no reliable order) or any other type raises InvalidParameterException.
    With strings_only, every element must be a string.
    """
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    if isinstance(value, str):
        return [value]
    if isinstance(value, (set, frozenset, dict, bytes)) or not isinstance(value, Iterable):
        raise InvalidParameterException(f"{name} must be a list (or a string), not {type(value).__name__}")
    items = list(value)
    if strings_only and not all(isinstance(item, str) for item in items):
        raise InvalidParameterException(f"{name} must contain only strings")
    return items


def as_pair_lists(left: Any, right: Any, left_name: str, right_name: str) -> tuple[list | None, list | None]:
    """
    Two lists paired by position (join columns, set operations). Two strings are one pair;
    a string with a list raises, because the pairing would be ambiguous.
    """
    left_list, right_list = as_list(left, left_name), as_list(right, right_name)
    if left_list and right_list and isinstance(left, str) != isinstance(right, str):
        raise InvalidParameterException(f"{left_name} and {right_name} must be both lists or both strings")
    return left_list, right_list


def as_dict(value: Any, name: str) -> dict | None:
    """None stays None; a dict is returned as it is; anything else raises InvalidParameterException."""
    if value is not None and not isinstance(value, dict):
        raise InvalidParameterException(f"{name} must be a dict, not {type(value).__name__}")
    return value


def as_number(value: Any, name: str) -> Any:
    """
    A number written straight into the SQL text (not sent as a bind): int, float, Decimal or numpy numbers.
    Text and bool (True is also an int in Python) raise InvalidParameterException.
    """
    if isinstance(value, bool) or not isinstance(value, (numbers.Real, decimal.Decimal)):
        raise InvalidParameterException(f"{name} must be a number, not {type(value).__name__}")
    return value
