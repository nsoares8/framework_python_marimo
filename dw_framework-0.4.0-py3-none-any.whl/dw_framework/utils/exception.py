class InvalidConnectionException(Exception):
    """This class is used when the connection does not exists or the cursor is null or even None"""

    def __init__(self, *args):
        super().__init__(*args)


class InvalidParameterException(Exception):
    """This class is used when the parameters passed throughtout the function is invalid, null or none"""

    def __init__(self, *args):
        super().__init__(*args)


class InvalidOptionParameterException(Exception):
    """This class is used when the option parameters passed throughtout the function is invalid, null or none"""

    def __init__(self, *args):
        super().__init__(*args)


class QueryNotExecutedException(Exception):
    """This class is used when the query is not executed"""

    def __init__(self, *args):
        super().__init__(*args)


class InvalidOperatorException(Exception):
    """This class is used when the operator is invalid"""

    def __init__(self, *args):
        super().__init__(*args)
