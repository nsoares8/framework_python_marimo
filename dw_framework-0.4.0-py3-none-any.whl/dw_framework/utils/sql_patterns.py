"""Regular expressions shared by the framework to inspect SQL."""

import re

# PL/SQL blocks and stored-code DDL (BEGIN, DECLARE, CREATE [OR REPLACE] PROCEDURE/FUNCTION/PACKAGE/TRIGGER/TYPE),
# also after leading comments (-- ... or /* ... */). They need their final ";", so _avoid_multiple_executions keeps it.
PLSQL_BLOCK = re.compile(
    r"^\s*(?:(?:--[^\n]*\n|/\*.*?\*/)\s*)*"
    r"(begin|declare|create\s+(or\s+replace\s+)?(procedure|function|package|trigger|type))\b",
    re.IGNORECASE | re.DOTALL,
)

# A "/" alone on the last line, as SQL Developer and SQL*Plus use to run a statement or a PL/SQL block.
TRAILING_SLASH = re.compile(
    r"\n\s*/\s*$",
)

# PARALLEL, NO_PARALLEL and NOPARALLEL hints as a whole word (not PARALLEL_INDEX, ENABLE_PARALLEL_DML...).
# Used to detect a parallel hint written by the user, so it is not mixed with the parallel= parameter.
PARALLEL_HINT = re.compile(
    r"(?<![\w$#])(NO_?)?PARALLEL(?![\w$#])",
    re.IGNORECASE,
)

# Column name or pattern with * (experimental.defaults.wide_numbers_columns): needs a letter, so "*" alone is rejected
COLUMN_PATTERN = re.compile(r"^(?=.*[A-Za-z])[A-Za-z*][A-Za-z0-9_$#*]*$")
