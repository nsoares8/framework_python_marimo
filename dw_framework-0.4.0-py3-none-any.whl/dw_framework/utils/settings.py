"""
Process-wide python-oracledb settings used by the framework.

These values live in oracledb.defaults and apply to every connection of the process:
DataStore, connectors, pools, pipelines and manual connections.

Applied when the framework is imported:
- fetch_lobs = False: LOB columns (CLOB, BLOB) are fetched as str/bytes. A LOB object can
  only be read while its connection is open, and the framework closes the connection at the
  end of each operation, so BLOB data would otherwise not be loaded.

Change or read any value with set_default / get_default:

Not changed by the framework (python-oracledb default):
- fetch_decimals = False: numbers are fetched as int/float. Use True to get Decimal
  (exact precision, but pandas columns become object).

>>> set_default("fetch_lobs", True)              # LOB objects instead of str/bytes
>>> set_default("fetch_decimals", True)          # Decimal instead of int/float
>>> set_default("program", "dag_carga_clientes")  # shown in V$SESSION.PROGRAM
>>> get_default("fetch_lobs")

fetch_lobs and fetch_decimal used to be constructor parameters of DataStore / Connection /
AsyncConnection; they were removed because these settings are process-wide, not per object.
"""

from typing import Any

import oracledb as oracle

from .exception import InvalidParameterException


def set_default(name: str, value: Any) -> None:
    """
    Change one python-oracledb default for the whole process (oracledb.defaults).
    Raises InvalidParameterException for names that do not exist, because python-oracledb
    would silently accept them without any effect (e.g. "fetch_decimal" instead of "fetch_decimals").
    https://python-oracledb.readthedocs.io/en/latest/api_manual/defaults.html

    >>> set_default("program", "dag_carga_clientes")   # shown in V$SESSION.PROGRAM
    """
    if not hasattr(oracle.defaults, name):
        raise InvalidParameterException(f"oracledb.defaults has no attribute {name!r}")
    setattr(oracle.defaults, name, value)


def get_default(name: str) -> Any:
    """Return one python-oracledb default (see set_default)."""
    if not hasattr(oracle.defaults, name):
        raise InvalidParameterException(f"oracledb.defaults has no attribute {name!r}")
    return getattr(oracle.defaults, name)


# Framework default: LOBs as str/bytes, so they can still be read after the connection is closed.
# To change it: set_default("fetch_lobs", True).
set_default("fetch_lobs", False)
