from typing import Any

import pandas as pd
import pyarrow as pa

from ..numpy_oracle_types import NUMPY_ORACLE_TYPE_MAP
from .exception import InvalidParameterException

# Same mapping with lowercase keys: both sides are compared in lowercase.
_TYPE_MAP = {key.lower(): value for key, value in NUMPY_ORACLE_TYPE_MAP.items()}


def dtype_name(dtype: Any) -> str:
    """
    Return the dtype name in lowercase, to compare with the lowercase keys of NUMPY_ORACLE_TYPE_MAP:
    the exact dtype name when it is mapped (pandas 3.x), otherwise the generic type name (older pandas / NumPy).
    """
    name = str(dtype).lower()
    if name in _TYPE_MAP:
        return name
    if hasattr(dtype, "type") and hasattr(dtype.type, "__name__"):
        return dtype.type.__name__.lower()
    return str(dtype.str).lower()


def oracle_column_types(data_frame: pd.DataFrame, columns: list[str] | None = None) -> dict[str, str]:
    """
    Map each DataFrame column to its Oracle type with NUMPY_ORACLE_TYPE_MAP.
    Raise InvalidParameterException if the type of any column is not mapped.

    >>> oracle_column_types(pd.DataFrame({"id": [1], "name": ["a"]}))
    {'id': 'NUMBER', 'name': 'VARCHAR2(4000)'}
    """
    if not isinstance(data_frame, pd.DataFrame):
        raise InvalidParameterException("data_frame must be a pandas DataFrame")

    types = {}
    for column, dtype in data_frame[columns or data_frame.columns.to_list()].dtypes.items():
        name = dtype_name(dtype)
        if name not in _TYPE_MAP:
            raise InvalidParameterException(f"Type {name} of column {column} is not in NUMPY_ORACLE_TYPE_MAP")
        types[column] = _TYPE_MAP[name]
    return types


def dataframe_to_arrow(data_frame: pd.DataFrame) -> pa.Table | list[tuple]:
    """
    Data ready for executemany / direct_path_load: an Arrow table (NaN/NaT -> NULL, category -> plain values),
    or a list of tuples when a column mixes types and Arrow cannot represent it.
    Building the Arrow table is much faster than converting row by row.
    """
    try:
        table = pa.Table.from_pandas(data_frame, preserve_index=False)
    except (pa.ArrowInvalid, pa.ArrowTypeError):
        data = data_frame.astype(object).where(data_frame.notna(), None)
        return list(data.itertuples(index=False, name=None))
    for i, field in enumerate(table.schema):
        if pa.types.is_dictionary(field.type):
            table = table.set_column(i, field.name, table.column(i).cast(field.type.value_type))
    return table


_INT64 = range(-(2**63), 2**63)


def has_wide_numbers(values: list[Any]) -> bool:
    """True when a column has an integer outside the int64 range (e.g. an id with 20 digits)."""
    return any(isinstance(value, int) and not isinstance(value, bool) and value not in _INT64 for value in values)
