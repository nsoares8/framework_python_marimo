from enum import Enum


class Aggregation(str, Enum):
    AVG = "AVG"
    SUM = "SUM"
    MIN = "MIN"
    MAX = "MAX"
    COUNT = "COUNT"
    VAR_POP = "VAR_POP"
    VAR_SAMP = "VAR_SAMP"
    STDDEV = "STDDEV"
    STDDEV_POP = "STDDEV_POP"
    STDDEV_SAMP = "STDDEV_SAMP"
    COVAR_POP = "COVAR_POP"
    COVAR_SAMP = "COVAR_SAMP"
    CORR = "CORR"
    MEDIAN = "MEDIAN"
