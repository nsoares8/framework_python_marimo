import base64
import re

from .exception import InvalidParameterException

BASE64_PATTERN = "^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$"
_NAME_PART = r"[A-Za-z][A-Za-z0-9_$#]*"
# Oracle name: owner.name optional, then an optional database link (it may contain . and @),
# e.g. vendas, dw.vendas, dw.vendas@dw_link, vendas@link.empresa.ao
IDENTIFIER_PATTERN = re.compile(rf"^{_NAME_PART}(\.{_NAME_PART})?(@{_NAME_PART}([.@]{_NAME_PART})*)?$")


def isbase64(password: str) -> bool:
    """True when password is base64 of readable text (Senha123 matches the pattern but decodes to binary noise)."""
    if re.match(BASE64_PATTERN, password) is None:
        return False
    try:
        text = base64.b64decode(password, validate=True).decode("utf-8")
    except ValueError:  # includes binascii.Error and UnicodeDecodeError
        return False
    return text.strip().isprintable()


def decode_password(password: None | str = None) -> str:
    """
    cib stands for convert into bytes
    the strip is used because some tools add
    /r and /n at the end of the string
    just to complete the format of base64
    A password that is not base64 is used as it is, with a warning: base64 keeps it from being read at a glance.
    """
    if password is not None and len(password) > 0:
        if isbase64(password=password):
            cib = str.encode(password)
            password = base64.b64decode(cib).decode("utf-8")
            return password.strip()
        else:
            print("We Strongly recomend you to set your password as base64 for minimum password requirement")
            return password.strip()
    else:
        raise InvalidParameterException("Password must be a string")


def convert_base64(password: str = "") -> str:
    """
    Method responsible to convert a password from base64 to utf8
    Since we do not store password nor provide secure, we recommend user to convert their password
    into base64 in order to not expose their password. We also recommend users to store the password into .env files

    Attributes:
        password: Text
        returns the utf8 password of user

    """
    encoded = base64.b64encode(str.encode(password)).decode("utf-8")
    return encoded.strip()


def checkInvalidCaracter(tablename: str) -> bool:
    """True when tablename is a valid Oracle name (see IDENTIFIER_PATTERN)."""
    return bool(IDENTIFIER_PATTERN.match(tablename))
