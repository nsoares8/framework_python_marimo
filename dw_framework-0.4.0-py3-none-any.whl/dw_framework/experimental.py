"""
Experimental options: they work, but their names and behaviour may still change.
Set like python-oracledb's defaults; turning one on shows a warning (UserWarning).

>>> from dw_framework.experimental import defaults
>>> defaults.wide_numbers = "text"
>>> defaults.wide_numbers_columns = ["X_CD_*", "ICCID"]
"""

import decimal
import fnmatch
import warnings
from typing import Any, Literal

import pyarrow as pa

from .utils.dataframe_types import has_wide_numbers
from .utils.exception import InvalidParameterException
from .utils.sql_patterns import COLUMN_PATTERN
from .utils.validation import as_list

WideNumbers = Literal["decimal", "text"]


class _Defaults:
    """
    wide_numbers: a NUMBER above the int64 range read row by row (e.g. an id with 20 digits)
      None      -> OverflowError naming the columns (the default; the rows read are lost);
      "decimal" -> those columns become decimal128(38, 0), or text above 38 digits;
      "text"    -> those columns become text.
    wide_numbers_columns: names or patterns with *, e.g. ["X_CD_*", "ICCID"]
      []   -> only the columns whose values do not fit are converted (their type depends on the data read);
      list -> those numeric columns are always converted, so they always have the same type; a number
              that does not fit in another column is also converted, with a warning naming it.
    An unknown name raises AttributeError (__slots__), so a typo is not silently ignored.
    """

    __slots__ = ("_wide_numbers", "_wide_numbers_columns")

    def __init__(self) -> None:
        self._wide_numbers: WideNumbers | None = None
        self._wide_numbers_columns: list[str] = []

    @property
    def wide_numbers(self) -> WideNumbers | None:
        return self._wide_numbers

    @wide_numbers.setter
    def wide_numbers(self, mode: WideNumbers | None) -> None:
        if mode not in (None, "decimal", "text"):
            raise InvalidParameterException('wide_numbers must be None, "decimal" or "text"')
        if mode is not None:
            warnings.warn("wide_numbers is experimental: its behaviour may change", UserWarning, stacklevel=2)
        self._wide_numbers = mode

    @property
    def wide_numbers_columns(self) -> list[str]:
        return list(self._wide_numbers_columns)

    @wide_numbers_columns.setter
    def wide_numbers_columns(self, columns: list[str] | str | None) -> None:
        patterns = [pattern.upper() for pattern in as_list(columns, "wide_numbers_columns") or []]
        if not all(COLUMN_PATTERN.match(pattern) for pattern in patterns):
            raise InvalidParameterException('wide_numbers_columns must be names or patterns with *, e.g. "X_CD_*"')
        self._wide_numbers_columns = patterns


defaults = _Defaults()


def _wide_array(values: list[Any], mode: WideNumbers) -> pa.Array | None:
    """A numeric column as decimal128(38, 0) or text (see _Defaults); None when it is not numeric."""
    if not all(
        value is None or (isinstance(value, int | float | decimal.Decimal) and not isinstance(value, bool))
        for value in values
    ):
        return None
    if mode == "decimal":
        try:
            return pa.array(values, type=pa.decimal128(38, 0))
        except (pa.ArrowInvalid, OverflowError, TypeError):  # more than 38 digits, or mixed with fractions
            pass
    return pa.array([None if value is None else str(value) for value in values])


def chosen_columns(names: list[str]) -> bool:
    """True when one of the names matches defaults.wide_numbers_columns (False without a list)."""
    patterns = defaults.wide_numbers_columns
    return any(fnmatch.fnmatchcase(name.upper(), pattern) for name in names for pattern in patterns)


def wide_numbers_table(columns: dict[str, list[Any]]) -> pa.Table:
    """Builds the table column by column with defaults.wide_numbers on (used by DataStoreType)."""
    mode = defaults.wide_numbers or "text"
    arrays: dict[str, pa.Array] = {}
    converted = []
    for name, values in columns.items():
        chosen = any(fnmatch.fnmatchcase(name.upper(), pattern) for pattern in defaults.wide_numbers_columns)
        if chosen or has_wide_numbers(values):
            wide = _wide_array(values, mode)  # None when the column is not numeric
            if wide is not None:
                arrays[name] = wide
                if not chosen:
                    converted.append(f"{name} ({'decimal' if pa.types.is_decimal(wide.type) else 'text'})")
                continue
        arrays[name] = pa.array(values)
    if converted:  # columns outside the list: their type depends on the data read, so say which changed
        warnings.warn(f"Numbers above the int64 range converted: {', '.join(converted)}", UserWarning, stacklevel=4)
    return pa.table(arrays)
