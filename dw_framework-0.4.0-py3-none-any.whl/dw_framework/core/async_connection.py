import asyncio
import os
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable
from typing import Any, LiteralString

import oracledb as oracle
import pandas as pd
import pyarrow as pa

from ..utils import settings  # noqa: F401  (applies the framework defaults, e.g. fetch_lobs=False)
from ..utils.encoding import decode_password, isbase64
from ..utils.exception import InvalidConnectionException, InvalidParameterException
from ..utils.sql_patterns import PLSQL_BLOCK, TRAILING_SLASH
from ..utils.validation import as_dict
from ..version import __version__ as _VERSION


class AsyncConnection(ABC):
    """Asynchronous connection class for managing Oracle Database connections.

    Same interface as Connection, but every database call is awaited.
    Parameters not passed default to the environment variables SERVERNAME, PORT,
    SERVICE, UNAME, UPDW, TNS_DNS and ORA_PATH.

    Parameters
    ----------
    host, port, service_name : str
        Used to build the DSN when no config directory is given.
    username, password : str
        Credentials. The password should be base64 encoded.
    tns_dns : str
        TNS alias, used together with config.
    config : str
        Directory with the Oracle client files (tnsnames.ora...).
    timeout : float
        Seconds to wait when opening the network connection. Default is 60.0.
    query_timeout : float, optional
        Maximum seconds of each round trip to the database (running a query or reading a batch).
        Default None: no limit.
    buffer_size : int
        Rows transferred per round trip, for queries and writes. Default is 10000.

    Notes
    -----
    How LOBs and numbers are fetched are process-wide python-oracledb settings, not parameters
    (see utils.settings):
    - LOB columns (CLOB, BLOB) are fetched as str/bytes, so they can still be read after the
      connection is closed. Change with set_default("fetch_lobs", True).
    - Numbers are fetched as int/float. Change with set_default("fetch_decimals", True) to get Decimal.
    The fetch_lobs and fetch_decimal constructor parameters were removed;
    see "Migração para a versão 0.4.0" in the README.
    """

    def __init__(
        self,
        buffer_size=10000,
        timeout=60.0,
        tns_dns: str | None = None,
        config: str | None = None,
        *,
        host: str | None = None,
        port: str | None = None,
        username: str | None = None,
        password: str | None = None,
        service_name: str | None = None,
        query_timeout: float | None = None,
    ):
        # Read here, not in the signature: defaults in the signature are read only once, at import time.
        self.__host = host or os.getenv("SERVERNAME")
        self.__port = port or os.getenv("PORT")
        self.__service_name = service_name or os.getenv("SERVICE")
        self.__username = username or os.getenv("UNAME")
        self.__password = decode_password(password=password or os.getenv("UPDW"))
        self.__tns_dsn = tns_dns or os.getenv("TNS_DNS")
        self.__config = self.check_config(path=config or os.getenv("ORA_PATH"))
        self.__timeout = timeout
        self.__buffer_size = buffer_size
        self.__query_timeout: float | None = None
        self.set_query_timeout(query_timeout)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"buffer_size={self.__buffer_size}, "
            f"timeout={self.__timeout}, "
            f"query_timeout={self.__query_timeout}, "
            f"tns_dns={self.__tns_dsn!r}, "
            f"config={self.__config!r}, "
            f"host={self.__host!r}, "
            f"port={self.__port!r}, "
            f"username={self.__username!r}, "
            f"password={'***' if self.__password else None}, "
            f"service_name={self.__service_name!r})"
        )

    def __str__(self):
        return (
            f"DataWareHouse Connection:\n"
            f"  Host: {self.__host or 'N/A'}\n"
            f"  Port: {self.__port or 'N/A'}\n"
            f"  Service: {self.__service_name or 'N/A'}\n"
            f"  User: {self.__username or 'N/A'}\n"
            f"  Timeout: {self.__timeout}s\n"
            f"  Query timeout: {self.__query_timeout or 'no limit'}\n"
            f"  Buffer Size: {self.__buffer_size}\n"
            f"  Config: {self.__config or 'N/A'}\n"
        )

    @property
    def username(self) -> str | None:
        """Returns the username for the database connection."""
        return self.__username

    @property
    def password(self) -> str | None:
        """Returns the password for the database connection."""
        return self.__password

    @property
    def config(self) -> str | None:
        """Returns the configuration directory for the database connection."""
        return self.__config

    def _avoid_multiple_executions(self, sql_statment: str) -> str:
        """
        Remove what tools like SQL Developer add at the end: a "/" alone on the last line and, outside
        PL/SQL, the final ';'. Nothing else is changed: python-oracledb runs one statement per call, so
        Oracle itself rejects several statements; '#', '--', ';' and comments inside the statement stay intact.
        PL/SQL blocks keep their final ';' (END;), also when they start with comments.
        https://python-oracledb.readthedocs.io/en/latest/user_guide/sql_execution.html
        """
        statement = TRAILING_SLASH.sub("", sql_statment.strip()).rstrip()
        if PLSQL_BLOCK.match(statement):
            return statement
        return statement.rstrip(";").rstrip()

    def _make_tns_dns(self) -> str:
        """
        Return the DSN: the TNS alias when a config directory is used,
        otherwise a DSN built from host, port and service name.

        Raises
        ------
        InvalidParameterException
            If the TNS alias is missing (with config), or host, port or service name is missing (without config).
        """
        if self.__config:
            if not self.__tns_dsn:
                raise InvalidParameterException("Please, provide the name of tns conection")
            return self.__tns_dsn

        if self.__host is None:
            raise InvalidParameterException("Host name must be defined")
        if self.__port is None:
            raise InvalidParameterException("Port must be defined")
        if self.__service_name is None:
            raise InvalidParameterException("Service name must be defined")

        self.__tns_dsn = oracle.makedsn(self.__host, self.__port, service_name=self.__service_name)  # type: ignore[arg-type]  # port read as text from PORT
        return self.__tns_dsn

    def check_config(self, path: str | None = "") -> str | None:
        """
        Validate the directory with the Oracle client files (tnsnames.ora...).

        Raises
        ------
        InvalidParameterException
            If the provided path is not a valid directory.

        https://docs.oracle.com/en/database/oracle/oracle-database/19/netrf/local-naming-parameters-in-tns-ora-file.html
        """
        if isinstance(path, str) and path:
            if os.path.isdir(path):
                return path
            raise InvalidParameterException("Invalid path")
        return path

    async def _execute_query(
        self,
        /,
        factoryrow: Callable[..., Any] | None = None,
        offset: int = 0,
        maxnumrows: int | None = 500,
        *,
        query_string: str = "",
        params: dict[str, Any] | None = None,
    ) -> list[Any]:
        """Execute a SELECT and return up to maxnumrows rows (all rows with None), skipping the first offset rows.

        Returns
        -------
        A list of dicts (column name -> value), or of the objects built by factoryrow.

        Example
        -------
        >>> await connection._execute_query(offset=10, maxnumrows=20, query_string="SELECT * FROM employees")
        """
        query_string = self._avoid_multiple_executions(query_string)
        # maxnumrows=None returns every row; offset/maxnumrows are only added when used.
        # params: the values of the :name binds written in the SQL; offset and maxnumrows are the framework's own
        _binds: dict[str, Any] = dict(as_dict(params, "params") or {})
        if reserved := {"offset", "maxnumrows"} & {str(name).lower() for name in _binds}:
            raise InvalidParameterException(f"params cannot use the bind names {', '.join(sorted(reserved))}")
        _internal_qry = query_string
        if offset:
            _internal_qry += " OFFSET :offset ROWS"
            _binds["offset"] = offset
        if maxnumrows is not None:
            _internal_qry += " FETCH NEXT :maxnumrows ROWS ONLY"
            _binds["maxnumrows"] = maxnumrows

        if _connection := await self._get_connection():
            async with _connection:
                cursor = _connection.cursor()
                cursor.arraysize = self.__buffer_size  # rows per round trip (default would be 100)
                cursor.prefetchrows = self.__buffer_size
                await cursor.execute(_internal_qry, _binds)

                if factoryrow is not None:
                    cursor.rowfactory = factoryrow
                    return await cursor.fetchall()

                columns = [col[0] for col in cursor.description or []]
                cursor.rowfactory = lambda *args: dict(zip(columns, args, strict=True))
                return await cursor.fetchall()
        raise InvalidConnectionException("Connection is not available")

    async def _get_connection(self) -> oracle.AsyncConnection:
        """Return a new connection with the stored credentials. Raise InvalidConnectionException if it fails."""
        return await self.__connect_async(username=self.__username, password=self.__password)

    async def _run_transaction(
        self,
        /,
        cursor: oracle.AsyncCursor,
        parameters: list | dict | tuple | pd.DataFrame | pa.Table | None = None,
        *,
        ddl_command: str = "",
        input_sizes: int | tuple | None = None,
        batch_size: int | None = None,
    ):
        """
        Run a DML or DDL command with the given cursor.
        With parameters (list of tuples/dicts, pandas DataFrame or Arrow table), runs executemany
        in blocks of batch_size rows (default: all at once) and checks the rejected rows after
        each block. The driver only keeps the errors of the last round trip, so a single
        executemany with batch_size could hide errors of the first blocks.

        Example
        -------
        >>> await connection._run_transaction(cursor=cursor, input_sizes=(20, 50),
        ...     parameters=[('value1', 'value2'), ('value3', 'value4')],
        ...     ddl_command="INSERT INTO my_table (column1, column2) VALUES (:1, :2)")
        """
        if input_sizes:
            # a tuple has one size per bind; a single value (e.g. an int) is the size of the only bind
            cursor.setinputsizes(*input_sizes) if isinstance(input_sizes, tuple) else cursor.setinputsizes(input_sizes)
        if parameters is None:
            await cursor.execute(ddl_command)
        elif isinstance(parameters, (list, pa.Array, pa.ChunkedArray, pa.Table, pd.DataFrame)):
            step = batch_size or max(len(parameters), 1)
            total = 0
            for start in range(0, len(parameters), step):
                if isinstance(parameters, (pa.Table, pa.Array, pa.ChunkedArray)):
                    chunk = parameters.slice(start, step)
                elif isinstance(parameters, pd.DataFrame):
                    chunk = parameters.iloc[start : start + step]
                else:
                    chunk = parameters[start : start + step]
                await cursor.executemany(ddl_command, chunk, batcherrors=True)
                if errors := cursor.getbatcherrors():
                    raise oracle.DatabaseError(errors[0])  # the executor rolls back everything
                total += cursor.rowcount
            print(f"Total of rows inserted: {total}")
        else:
            raise TypeError("Invalid datatype")

    async def _dml_or_ddl_executor(
        self,
        /,
        input_sizes: int | tuple | None = None,
        parameters: list | dict | tuple | None = None,
        *,
        ddl_command: str = "",
        batch_size: int | None = None,
    ) -> bool:
        """
        Execute a DML or DDL command in its own connection and transaction.
        Commit on success, rollback on error.

        Returns
        -------
        True if the command was committed, False otherwise.
        """
        _execution_status: bool = False
        connection = None
        try:
            connection = await self._get_connection()
            if not connection:
                raise InvalidConnectionException("No database connection")
            connection.autocommit = False
            cursor = connection.cursor()
            cursor.arraysize = self.__buffer_size
            cursor.prefetchrows = self.__buffer_size

            await self._run_transaction(
                cursor=cursor,
                parameters=parameters,
                ddl_command=self._avoid_multiple_executions(ddl_command),
                input_sizes=input_sizes,
                batch_size=batch_size,
            )
            await connection.commit()
            _execution_status = True
        except (oracle.DatabaseError, oracle.DataError, InvalidConnectionException) as exc:
            (error,) = exc.args
            print(
                f"This exception was thrown because of {getattr(error, 'message', error)}, so rolling back all the changes"
            )
            if connection:
                await connection.rollback()
        finally:
            if connection:
                await connection.close()
        return _execution_status

    async def __connect_async(
        self, *, username: str | None = None, password: str | None = None
    ) -> oracle.AsyncConnection:
        """Open a connection with the given credentials. Raise InvalidConnectionException if it fails."""
        try:
            if self.__config:
                connection = await oracle.connect_async(
                    user=f"{username}",
                    password=password,
                    dsn=self._make_tns_dns(),
                    tcp_connect_timeout=self.__timeout,
                    config_dir=self.__config,
                )
            else:
                connection = await oracle.connect_async(
                    user=f"{username}", password=password, dsn=self._make_tns_dns(), tcp_connect_timeout=self.__timeout
                )
        except oracle.DatabaseError as exc:
            (error,) = exc.args
            raise InvalidConnectionException(f"Could not connect to the database: {error.message}") from exc
        if self.__query_timeout:
            connection.call_timeout = int(self.__query_timeout * 1000)  # the driver takes milliseconds
        return connection

    async def _direct_path_load(self, table_name: str, columns: list, data: Any, batch_size: int | None = None) -> bool:
        """
        Driver Direct Path Load API, asynchronous (python-oracledb 3.4+, Oracle 12.1+). The fastest method,
        with minimal redo. The rows are committed by the load itself (no rollback) and the table is
        locked during the load, so use it for new or staging tables.
        https://python-oracledb.readthedocs.io/en/latest/user_guide/batch_statement.html#direct-path-loads
        """
        owner, _, name = table_name.upper().rpartition(".")
        try:
            connection = await self._get_connection()
            async with connection:
                await connection.direct_path_load(
                    schema_name=owner or str(self.__username).upper(),
                    table_name=name,
                    column_names=[str(column).upper() for column in columns],
                    data=data,
                    batch_size=batch_size or self.__buffer_size,
                )
            return True
        except (oracle.DatabaseError, oracle.DataError, InvalidConnectionException) as exc:
            print("This error was thrown because ", exc)
            return False

    async def _append_values_load(
        self, table_name: str, columns: list, data: Any, batch_size: int | None = None, partition: str | None = None
    ) -> bool:
        """
        Direct-path INSERT through SQL (INSERT /*+ APPEND_VALUES */), asynchronous: Oracle 12.1+ (asyncio
        needs Thin mode), any python-oracledb version with asyncio. One transaction per block of batch_size
        rows, because a second direct-path insert into the same table in the same transaction raises
        ORA-12838. Blocks already committed stay in the table if a later block fails.
        With partition, inserts into that partition only (INSERT ... INTO t PARTITION (p)): Oracle locks
        only that partition and rejects rows that do not belong to it (ORA-14401).
        """
        binds = ", ".join(f":{index}" for index in range(1, len(columns) + 1))
        target = f"{table_name} PARTITION ({partition})" if partition else table_name
        sql = f"INSERT /*+ APPEND_VALUES */ INTO {target} ({', '.join(map(str, columns))}) VALUES ({binds})"
        rows = (
            data if isinstance(data, list) else list(zip(*(column.to_pylist() for column in data.columns), strict=True))
        )
        step = batch_size or self.__buffer_size
        try:
            connection = await self._get_connection()
            async with connection:
                cursor = connection.cursor()
                for start in range(0, len(rows), step):
                    await cursor.executemany(sql, rows[start : start + step])
                    await connection.commit()  # ends the direct-path transaction of this block
            return True
        except (oracle.DatabaseError, oracle.DataError, InvalidConnectionException) as exc:
            print("This error was thrown because ", exc)
            return False

    async def _load_partitions(
        self,
        table_name: str,
        partitions: dict[str, Any],
        columns: list,
        batch_size: int | None = None,
        workers: int = 4,
    ) -> dict[str, bool]:
        """
        Load several partitions of the same table at the same time, asynchronous: up to workers partitions
        in parallel, each in its own connection with a direct-path INSERT into its own partition
        (only that partition is locked). Returns {partition: True/False}; each partition is independent.
        """
        limit = asyncio.Semaphore(workers)

        async def load(partition: str, data: Any) -> bool:
            async with limit:
                return await self._append_values_load(table_name, columns, data, batch_size, partition)

        results = await asyncio.gather(*(load(partition, data) for partition, data in partitions.items()))
        return dict(zip(partitions, results, strict=True))

    async def _bulk_load(
        self, table_name: str, columns: list, data: Any, batch_size: int | None = None, method: str = "auto"
    ) -> bool:
        """
        Fast load into new or staging tables, asynchronous.
        method="auto": the driver Direct Path Load when available, otherwise APPEND_VALUES.
        method="direct_path" or "append_values": that one only.
        """
        if method == "auto":
            connection = await self._get_connection()
            async with connection:
                method = "direct_path" if hasattr(connection, "direct_path_load") else "append_values"
        loader = {"direct_path": self._direct_path_load, "append_values": self._append_values_load}.get(method)
        if loader is None:
            raise InvalidParameterException("method must be 'auto', 'direct_path' or 'append_values'")
        return await loader(table_name, columns, data, batch_size)

    def set_query_timeout(self, seconds: float | None) -> None:
        """
        Maximum seconds of each round trip to the database: running the query, or reading one batch.
        A round trip that takes longer raises DPY-4024 (in writes: rollback and False). None: no limit.
        Not the same as timeout, which only limits opening the network connection.
        """
        if seconds is not None and (isinstance(seconds, bool) or not isinstance(seconds, int | float) or seconds <= 0):
            raise InvalidParameterException("query_timeout must be a number of seconds greater than zero, or None")
        self.__query_timeout = seconds

    def get_query_timeout(self) -> float | None:
        """The limit set with query_timeout / set_query_timeout (None: no limit)."""
        return self.__query_timeout

    def set_buffer(self, buffer_size: int):
        """Set how many rows are transferred per round trip."""
        if not buffer_size:
            raise InvalidParameterException("Buffer can't be None")
        self.__buffer_size = buffer_size

    def get_buffer(self) -> int:
        """Return how many rows are transferred per round trip."""
        return self.__buffer_size

    def get_tns_dsn(self) -> str:
        """Return the DSN used to connect."""
        return self._make_tns_dns()

    async def check_health(self) -> str:
        """Return ':Ok' if a healthy connection can be opened, ':Nok' otherwise."""
        try:
            connection = await self._get_connection()
        except InvalidConnectionException:
            return ":Nok"
        async with connection:
            return ":Ok" if connection.is_healthy() else ":Nok"

    @property
    def __version__(self) -> str:
        return _VERSION

    @property
    def timeout(self) -> float:
        return self.__timeout

    @timeout.setter
    def timeout(self, value: float = 60.0):
        self.__timeout = 60.0 if value is None else value

    def rewrite_connection(
        self,
        username: str | None = None,
        password: str | None = None,
        tns_dns: str | None = None,
        config: str | None = None,
        timeout: float | None = None,
    ) -> None:
        """Change the connection parameters without creating a new instance.
        Only the parameters passed are changed.

        Example
        -------
        >>> dw.rewrite_connection(username='new_user', password='new_password', timeout=120.0)
        """
        if isinstance(username, str) and username:
            self.__username = username

        if isinstance(password, str) and password:
            if isbase64(password=password):
                self.__password = decode_password(password)
            else:
                print("We Strongly recomend to use base64")
                self.__password = password

        if isinstance(tns_dns, str):
            self.__tns_dsn = tns_dns

        if isinstance(config, str):
            if not os.path.isdir(config):
                raise InvalidParameterException("Config must be an directory")
            self.__config = config

        if isinstance(timeout, (int, float)):
            self.timeout = timeout

    async def fetch_as_oracle_dataframe(
        self,
        parameters: list[Any] | dict[str, Any] | None = None,
        buffer_size: int | None = None,
        *,
        query_string: str = "",
        schema: Any = None,
    ):
        """Execute a query and return the whole result as an Oracle DataFrame.

        Example
        -------
        >>> df = await dw.fetch_as_oracle_dataframe(buffer_size=100, query_string="SELECT * FROM employees")
        """
        try:
            if _connection := await self._get_connection():
                async with _connection:
                    return await _connection.fetch_df_all(
                        statement=query_string, arraysize=buffer_size, parameters=parameters, requested_schema=schema
                    )
            raise InvalidConnectionException("Database is not availabe")
        except (oracle.DatabaseError, oracle.DataError) as exc:
            (error,) = exc.args
            print(f"This exception was thrown because of  {error.message}")

    async def fetch_as_oracle_batch_dataframe(
        self,
        /,
        buffer_size: int | None = 0,
        *,
        query_string: str = "",
        schema: Any = None,
        parameters: list[Any] | dict[str, Any] | None = None,
    ):
        """Execute a query and yield the result in Oracle DataFrames of buffer_size rows.

        Example
        -------
        >>> async for df in dw.fetch_as_oracle_batch_dataframe(buffer_size=100, query_string="SELECT * FROM employees"):
        ...     process(df)
        """
        _connection = await self._get_connection()
        if not _connection:
            raise InvalidConnectionException("Database is not availabe")
        try:
            async with _connection:
                # fetch_df_batches is an async generator in AsyncConnection; the driver stubs say Iterator
                async for batch in _connection.fetch_df_batches(  # type: ignore[attr-defined]
                    statement=query_string, parameters=parameters, size=buffer_size, requested_schema=schema
                ):
                    yield batch
        except (oracle.DatabaseError, oracle.DataError) as exc:
            (error,) = exc.args
            print(f"This exception was thrown because of  {error.message}")

    async def _procedure(
        self,
        /,
        cursor: oracle.AsyncCursor | None = None,
        procedure_name: LiteralString = "",
        parameters: list[Any] | None = None,
    ) -> Iterable | None:
        """
        Call a stored procedure with the given cursor.

        Example
        -------
        >>> await connection._procedure(cursor=my_cursor, procedure_name='my_procedure', parameters=[param1, param2])
        """
        if procedure_name is None or not isinstance(procedure_name, str):
            raise InvalidParameterException("procedure must be a string name")

        if parameters is not None and not isinstance(parameters, list):
            raise TypeError("parameters must be a list of values")

        if not isinstance(cursor, oracle.AsyncCursor):
            raise TypeError("cursor must be a instance of oracle")

        try:
            return await cursor.callproc(procedure_name, parameters or [])
        except (oracle.DatabaseError, oracle.DataError) as exc:
            (error,) = exc.args
            print(f"This exception was thrown because of  {error.message}")
            return None

    async def _function(
        self,
        /,
        cursor: oracle.AsyncCursor | None = None,
        function_name: LiteralString = "",
        parameters: list[Any] | None = None,
        output_type: type | None = None,
    ) -> Any:
        """
        Call a stored function with the given cursor and return its result.

        Example
        -------
        >>> await connection._function(cursor=my_cursor, function_name='my_function', parameters=[param1], output_type=str)
        """
        if output_type is not None and not isinstance(output_type, type):
            raise TypeError("parameters must be a class of types")

        if not isinstance(cursor, oracle.AsyncCursor):
            raise InvalidParameterException("cursor must be a instance of oracle")

        try:
            return await cursor.callfunc(function_name, output_type, parameters)
        except (oracle.DatabaseError, oracle.DataError) as exc:
            (error,) = exc.args
            print(f"This exception was thrown because of  {error.message}")

    @abstractmethod
    def version(self):
        raise NotImplementedError

    @property
    def tns_dns(self):
        return self._make_tns_dns()
