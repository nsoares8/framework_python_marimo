from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from typing import Any, LiteralString

import oracledb as oracle
import pandas as pd

from .data_store_type import DataStoreType

RowFactory = Callable[..., Any] | None
QueryRows = DataStoreType | list[Any]


class IDataStore(ABC):
    """
    Interface for Data Warehouse operations.

    Methods:
    - get_connection: Establishes a connection to the data warehouse.
    - query: Executes a query and returns results.
    - load_data_frame: Creates a table from a pandas DataFrame and loads the data into it.
    - query_as_oracle_data_frame: Executes a query and returns results as an Oracle DataFrame.
    - query_batch_as_oracle_data_frame: Executes a query and returns results in batches of Oracle DataFrames.
    - insert: Inserts one or multiple records into a table.
    - load_into_database: Loads data from a DataFrame into an existing table.
    - drop_table: Drops a specified table from the database.
    - truncate_table: Truncates a specified table in the database.
    - update: Updates records in a specified table based on conditions.
    - delete: Deletes records from a specified table based on conditions.
    - create_table: Creates a new table in the database.
    - subset: Rows that exist in both tables (INTERSECT).
    - union: Performs a union operation between two tables.
    - minus: Performs a minus operation between two tables.
    - join: Joins two tables based on specified columns and conditions.
    - truncate_partition: Truncates a partition of a specified table.
    - exchange_partition: Exchanges a partition between two tables.
    - split_partition: Splits a partition of a specified table.
    - eprocedure: Executes a stored procedure in the database.
    - efunction: Executes a stored function in the database.
    """

    @abstractmethod
    def get_connection(self):
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def query(
        self,
        /,
        factoryrow: RowFactory = None,
        offset: int = 0,
        maxnumrows: int | None = 500,
        *,
        query_string: str = "",
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def load_data_frame(
        self,
        /,
        table_space_name: str = "DW_USERS",
        compression: str = "QUERY LOW",
        *,
        dataframe: pd.DataFrame,
        table_name: str = "",
        inputsize: tuple | None = None,
        batch: bool = False,
        chunksize: int | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def query_as_oracle_data_frame(
        self,
        *,
        query_string: str = "",
        params: dict[str, Any] | None = None,
        buffer_size: int | None = None,
        schema: Any = None,
    ) -> oracle.DataFrame:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def query_batch_as_oracle_data_frame(
        self,
        *,
        query_string: str = "",
        params: dict[str, Any] | None = None,
        buffer_size: int | None = None,
        schema: Any = None,
    ) -> Iterator[oracle.DataFrame]:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def insert(
        self,
        input_sizes: tuple | None = None,
        /,
        *,
        table: str = "",
        columns: list | None = None,
        values: list[tuple] | Any | None = None,
        batch_size: int | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def load_into_database(
        self,
        *,
        data_frame: pd.DataFrame | None = None,
        table_name: str = "",
        columns: list | None = None,
        inputsize: tuple[int, ...] | None = None,
        batch_size: int | None = None,
        direct: bool = False,
        method: str = "auto",
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def drop_table(self, /, purge: bool = True, *, table_name: str | None = None) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def truncate_table(self, /, *, table_name: str | None = None) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def update(
        self,
        /,
        where: dict | None = None,
        ari: str = "=",
        operator: str = "AND",
        *,
        table: str = "",
        keyvalues: dict | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def delete(self, operator: str = "AND", ari: str = "=", *, table: str = "", where: dict | None = None) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def create_table(
        self,
        /,
        table_space_name: str | None = "DW_USERS",
        compression: str | None = "QUERY LOW",
        *,
        table_name: str | None = None,
        columns: list | None = None,
        column_type: list | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def subset(
        self,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list[str] | None = None,
        right_columns: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def union(
        self,
        keep_all: bool = True,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list[str] | None = None,
        right_columns: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def minus(
        self,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list | None = None,
        right_columns: list | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def join(
        self,
        /,
        left_alias: str | None = "lt",
        right_alias: str | None = "rt",
        strategy: str = "JOIN",
        column: list[str] | None = None,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        on_left_columns: list[str] | None = None,
        on_right_columns: list[str] | None = None,
        where: str = "1=1",
        groupby: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def truncate_partition(self, table_name: str, partition_name: str) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def exchange_partition(
        self,
        /,
        options: str | None = None,
        *,
        left_table: str | None = None,
        right_table: str | None = None,
        partition: str | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def split_partition(
        self,
        /,
        value: tuple[str, ...] | None = None,
        at: str | None = None,
        *,
        table_name: str,
        partition: str,
        other_partition: list[dict],
        options: str | None = None,
    ) -> bool:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def eprocedure(
        self,
        /,
        cursor: oracle.Cursor | None = None,
        procedure_name: LiteralString = "",
        parameters: list[Any] | None = None,
    ) -> Any:
        raise NotImplementedError("This method must be implemented")

    @abstractmethod
    def efunction(
        self,
        /,
        cursor: oracle.Cursor | None = None,
        function_name: LiteralString = "",
        parameters: list[Any] | None = None,
        output_type: type | None = None,
    ) -> Any:
        raise NotImplementedError("This method must be implemented")
