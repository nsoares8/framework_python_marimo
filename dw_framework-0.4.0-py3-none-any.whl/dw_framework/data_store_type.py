from abc import ABC, abstractmethod

from collections.abc import Callable, Iterator
from typing import TYPE_CHECKING, Any, cast

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from .experimental import chosen_columns, wide_numbers_table
from .experimental import defaults as experimental
from .utils.dataframe_types import has_wide_numbers

if TYPE_CHECKING:  # polars is only loaded when to_polars() is called (see to_polars)
    import polars as pl


class IDataStoreType(ABC):
    @abstractmethod
    def to_list(self) -> list[dict[str, Any]]:
        pass

    @abstractmethod
    def to_pandas(self) -> pd.DataFrame:
        pass

    @abstractmethod
    def to_polars(self) -> "pl.DataFrame":
        pass

    @abstractmethod
    def to_arrow(self) -> pa.Table:
        pass

    @abstractmethod
    def to_parquet(self, path: str) -> None:
        pass


class DataStoreType(IDataStoreType):
    """
    DataStoreType is a wrapper around pyarrow.Table that provides methods to convert the data to different formats.
    It can be initialized with a list of dictionaries, a dictionary of lists, a pyarrow.Table or None (empty table).

    Example
    -------
    >>> ds = DataStoreType([{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}])
    >>> ds[0]
    {'name': 'Alice', 'age': 30}
    >>> ds["name"]
    ['Alice', 'Bob']
    >>> ds.to_pandas()
    >>> ds.to_parquet("data.parquet")
    """

    def __init__(self, data: list[dict[str, Any]] | dict[str, list[Any]] | pa.Table | None = None):
        if isinstance(data, pa.Table):
            self._table = data
        elif isinstance(data, list):
            self._table = self._build(
                lambda: pa.Table.from_pylist(data),
                lambda: {name: [row.get(name) for row in data] for name in data[0]},
                list(data[0]) if data else [],
            )
        elif isinstance(data, dict):
            self._table = self._build(lambda: pa.Table.from_pydict(data), lambda: data, list(data))
        else:
            self._table = pa.Table.from_pylist([])

    @classmethod
    def _build(
        cls, build: Callable[[], pa.Table], columns: Callable[[], dict[str, list[Any]]], names: list[str]
    ) -> pa.Table:
        """
        The normal build, or the experimental conversion of numbers above int64 (dw_framework.experimental).
        columns is only built when it is needed, so the normal path does not change.
        """
        if experimental.wide_numbers and chosen_columns(names):  # chosen columns: always converted
            return wide_numbers_table(columns())
        try:
            return build()
        except (OverflowError, pa.ArrowInvalid) as exc:  # ArrowInvalid: a big int mixed with fractions
            data = columns()
            names = [name for name, values in data.items() if has_wide_numbers(values)]
            if not names:
                raise  # another conversion problem: as it is
            if experimental.wide_numbers:
                return wide_numbers_table(data)
            raise OverflowError(cls._overflow_message(names)) from exc

    @staticmethod
    def _overflow_message(names: list[str]) -> str:
        """Names the NUMBER columns above the int64 range and the ways to read them."""
        return (
            f"Numbers above the int64 range in column(s) {', '.join(names)} (e.g. ids with 20 digits). Options:\n"
            '  - set_default("fetch_decimals", True): numbers are read as Decimal (every NUMBER column);\n'
            f"  - read the column as text in the query: TO_CHAR({names[0]}) {names[0]};\n"
            "  - keep the rows and convert it (experimental): from dw_framework.experimental import defaults;"
            f' defaults.wide_numbers = "text"; defaults.wide_numbers_columns = ["{names[0]}"]'
        )

    def __len__(self) -> int:
        return self._table.num_rows

    def __getitem__(self, key: int | str | slice):
        """ds[0] -> row as dict, ds[1:3] -> list of rows, ds["col"] -> list of values of a column."""
        if isinstance(key, int):
            index = key + self._table.num_rows if key < 0 else key
            if index < 0 or index >= self._table.num_rows:
                raise IndexError("row index out of range")
            return self._table.slice(index, 1).to_pylist()[0]

        if isinstance(key, slice):
            start, stop, step = key.indices(self._table.num_rows)
            if step == 1:
                return self._table.slice(start, max(stop - start, 0)).to_pylist()
            return self._table.take(list(range(start, stop, step))).to_pylist()

        if isinstance(key, str):
            return self._table[key].to_pylist()

        raise TypeError("key must be int, slice or str")

    def __iter__(self) -> Iterator[dict[str, Any]]:
        """Returns an iterator over the rows of the data as dictionaries."""
        yield from self._table.to_pylist()

    def to_arrow(self) -> pa.Table:
        """Returns the data as a pyarrow.Table."""
        return self._table

    def to_list(self) -> list[dict[str, Any]]:
        """Returns the data as a list of dictionaries."""
        return self._table.to_pylist()

    def to_pandas(self) -> pd.DataFrame:
        """
        Returns the data as a pandas DataFrame.
        Note: This method may be memory intensive for large datasets. Consider using to_polars() for larger datasets.
        """
        return self._table.to_pandas()

    def to_polars(self) -> "pl.DataFrame":
        """
        Returns the data as a polars DataFrame.
        Note: This method is more memory efficient than to_pandas() for large datasets.
        """
        try:
            import polars as pl  # optional dependency (about 190 MB): loaded only when needed
        except ImportError as exc:
            raise ImportError('to_polars() needs polars: pip install "dw_framework[polars]"') from exc

        return cast(pl.DataFrame, pl.from_arrow(self._table))

    def to_parquet(self, path: str) -> None:
        """Saves the data as a parquet file at the specified path."""
        pq.write_table(self._table, path)
