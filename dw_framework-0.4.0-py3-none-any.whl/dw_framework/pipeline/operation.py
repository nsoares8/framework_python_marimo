from typing import Any

import oracledb as oracle
import pandas as pd

from ..core import AsyncConnection
from ..utils.dataframe_types import oracle_column_types
from ..utils.validation import as_dict, as_list, check_names
from ..utils.exception import InvalidConnectionException, InvalidParameterException, QueryNotExecutedException


# ---------------------------------------------------------------- ingestion steps
# Each function adds one operation to an oracle.Pipeline and returns it.


def add_truncate(pipeline: oracle.Pipeline, table: str) -> oracle.PipelineOp:
    """ Empty a table (TRUNCATE). Oracle commits it immediately and it cannot be rolled back. """
    check_names(table)
    return pipeline.add_execute(f"TRUNCATE TABLE {table}")


def add_insert(pipeline: oracle.Pipeline, table: str, rows: list[tuple],
               columns: list[str] | None = None) -> oracle.PipelineOp:
    """ Insert rows with binds (executemany). Without columns, each tuple must fill every column in table order.

        >>> add_insert(pipeline, "stg_users", [("Alice", 30), ("Bob", 25)], columns=["name", "age"])
    """
    columns = as_list(columns, "columns")
    check_names(table, *(columns or []))
    rows = as_list(rows, "rows", strings_only=False)
    if not rows:
        raise InvalidParameterException("rows must be defined")
    if not all(isinstance(row, (list, tuple, dict)) for row in rows):
        raise InvalidParameterException("rows must be a list of tuples (one per row)")
    binds = ", ".join(f":{index}" for index in range(1, len(rows[0]) + 1))
    target_columns = f" ({', '.join(columns)})" if columns else ""
    return pipeline.add_executemany(f"INSERT INTO {table}{target_columns} VALUES ({binds})", rows)


def add_dataframe(pipeline: oracle.Pipeline, table: str, data_frame: pd.DataFrame, columns: list[str] | None = None,
                  chunksize: int | None = None) -> list[oracle.PipelineOp]:
    """ Insert the rows of a DataFrame. Without columns, uses every DataFrame column. NaN/NaT become NULL.
        The column types are checked against NUMPY_ORACLE_TYPE_MAP before anything is added to the pipeline.
        With chunksize, splits the rows into several inserts, to limit the size of each one.

        >>> add_dataframe(pipeline, "stg_events", df, chunksize=50_000)
    """
    if not isinstance(data_frame, pd.DataFrame):
        raise InvalidParameterException("data_frame must be a pandas DataFrame")
    columns = as_list(columns, "columns") or data_frame.columns.to_list()
    oracle_column_types(data_frame, columns)   # raises if a column type is not in NUMPY_ORACLE_TYPE_MAP
    chunksize = chunksize or max(len(data_frame), 1)
    operations = []
    for start in range(0, len(data_frame), chunksize):
        data = data_frame[columns].iloc[start:start + chunksize]
        data = data.astype(object).where(data.notna(), None)
        operations.append(add_insert(pipeline, table, list(data.itertuples(index=False, name=None)), columns))
    return operations


def add_delete(pipeline: oracle.Pipeline, table: str, where: dict[str, Any] | str | None = None,
               parameters: dict[str, Any] | None = None) -> oracle.PipelineOp:
    """ Delete rows. where can be:
        - a dict: every {column: value} must match (equality, joined with AND);
        - a string: any condition, with its binds in parameters;
        - None: deletes every row.

        >>> add_delete(pipeline, "events", {"load_date": date(2026, 10, 16)})
        >>> add_delete(pipeline, "events", "event_date >= :start AND event_date < :end",
        ...            {"start": date(2026, 10, 1), "end": date(2026, 11, 1)})
    """
    check_names(table)
    if not where:
        return pipeline.add_execute(f"DELETE FROM {table}")
    if isinstance(where, str):
        return pipeline.add_execute(f"DELETE FROM {table} WHERE {where}", parameters)
    where = as_dict(where, "where")                     # {column: value}, or a text condition (above)
    check_names(*where)
    conditions = " AND ".join(f"{column} = :{column}" for column in where)
    return pipeline.add_execute(f"DELETE FROM {table} WHERE {conditions}", where)


def add_merge(pipeline: oracle.Pipeline, source: str, target: str, on_: list[str],
              update_values: dict[str, str] | None = None, insert_values: dict[str, str] | None = None,
              target_alias: str = "target", source_alias: str = "source") -> oracle.PipelineOp:
    """ Update the rows of target that match source and insert the others.
        Values are SQL expressions; columns in on_ cannot be in update_values (ORA-38104).

        >>> add_merge(pipeline, "stg_users", "users", ["source.id = target.id"],
        ...           update_values={"name": "source.name"}, insert_values={"id": "source.id", "name": "source.name"})
    """
    check_names(target)
    on_ = as_list(on_, "on_")
    update_values, insert_values = as_dict(update_values, "update_values"), as_dict(insert_values, "insert_values")
    if not on_ or (not update_values and not insert_values):
        raise InvalidParameterException("on_ and update_values or insert_values must be defined")

    query = f"MERGE INTO {target} {target_alias} USING {source} {source_alias} ON ({' AND '.join(on_)})"
    if update_values:
        query += " WHEN MATCHED THEN UPDATE SET " + ", ".join(
            f"{target_alias}.{column} = {value}" for column, value in update_values.items())
    if insert_values:
        query += (f" WHEN NOT MATCHED THEN INSERT ({', '.join(insert_values)})"
                  f" VALUES ({', '.join(map(str, insert_values.values()))})")
    return pipeline.add_execute(query)


def add_count(pipeline: oracle.Pipeline, table: str, where: str = "1=1") -> oracle.PipelineOp:
    """ Count the rows of a table, to check the load. The result is in rows[0][0] of this operation. """
    check_names(table)
    return pipeline.add_fetchone(f"SELECT COUNT(1) FROM {table} WHERE {where}")


def add_exchange_partition(pipeline: oracle.Pipeline, table: str, staging: str, partition: str,
                           options: str | None = None) -> oracle.PipelineOp:
    """ Swap a partition of table with the staging table (almost instant, no rows are copied).
        options: INCLUDING/EXCLUDING INDEXES, WITH/WITHOUT VALIDATION, UPDATE GLOBAL INDEXES.

        >>> add_exchange_partition(pipeline, "cdr_voice", "stg_cdr_voice", "P20261016", "WITHOUT VALIDATION")
    """
    check_names(table, staging, partition)
    query = f"ALTER TABLE {table} EXCHANGE PARTITION {partition} WITH TABLE {staging}"
    return pipeline.add_execute(f"{query} {options}" if options else query)


def add_gather_stats(pipeline: oracle.Pipeline, table: str, partition: str | None = None) -> oracle.PipelineOp:
    """ Gather the optimizer statistics of a table (or of one partition) after a load.
        Accepts table or owner.table; without owner, uses the current user.

        >>> add_gather_stats(pipeline, "dw.cdr_voice", partition="P20261016")
    """
    check_names(table)
    owner, _, name = table.upper().rpartition(".")
    return pipeline.add_execute(
        "BEGIN DBMS_STATS.GATHER_TABLE_STATS(ownname => NVL(:owner, USER), tabname => :name, partname => :part); END;",
        {"owner": owner or None, "name": name, "part": partition.upper() if partition else None})


def add_procedure(pipeline: oracle.Pipeline, name: str, parameters: list[Any] | None = None,
                  keyword_parameters: dict[str, Any] | None = None) -> oracle.PipelineOp:
    """ Call a PL/SQL procedure as a pipeline step.

        >>> add_procedure(pipeline, "dw_etl.load_day", ["2026-10-16"])
    """
    parameters = as_list(parameters, "parameters", strings_only=False)       # "x" is one parameter, not 1 per letter
    keyword_parameters = as_dict(keyword_parameters, "keyword_parameters")
    return pipeline.add_callproc(name, parameters, keyword_parameters)


def add_count_duplicates(pipeline: oracle.Pipeline, table: str, keys: list[str]) -> oracle.PipelineOp:
    """ Count how many keys appear more than once. 0 means no duplicates. Result in rows[0][0].

        >>> add_count_duplicates(pipeline, "stg_users", ["id"])
    """
    keys = as_list(keys, "keys")
    if not keys:
        raise InvalidParameterException("keys must be defined")
    check_names(table, *keys)
    columns = ", ".join(keys)
    return pipeline.add_fetchone(
        f"SELECT COUNT(1) FROM (SELECT {columns} FROM {table} GROUP BY {columns} HAVING COUNT(1) > 1)")


def add_count_nulls(pipeline: oracle.Pipeline, table: str, columns: list[str]) -> oracle.PipelineOp:
    """ Count the NULL values of each column. Result: one row with one count per column, in the same order.

        >>> add_count_nulls(pipeline, "stg_users", ["id", "name"])
    """
    columns = as_list(columns, "columns")
    if not columns:
        raise InvalidParameterException("columns must be defined")
    check_names(table, *columns)
    counts = ", ".join(f"COUNT(CASE WHEN {column} IS NULL THEN 1 END) AS {column}" for column in columns)
    return pipeline.add_fetchone(f"SELECT {counts} FROM {table}")


def result_to_dataframe(result: Any) -> pd.DataFrame:
    """ Convert the result of a fetch operation (add_fetchall, add_fetchone, add_count...) into a DataFrame.

        >>> results = await op.run_pipeline_async(pipeline)
        >>> df = result_to_dataframe(results[0])
    """
    if not result.columns:
        raise InvalidParameterException("This operation does not return rows")
    return pd.DataFrame(result.rows, columns=[column.name for column in result.columns])


def raise_if_failed(results: list[Any], fail_on_warning: bool = False) -> None:
    """ Raise QueryNotExecutedException if any operation of a pipeline run with continue_on_error=True
        has an error (or a warning, with fail_on_warning=True). The message lists every failed operation.

        With continue_on_error=False this is not needed: run_pipeline already raises at the first error.
        https://python-oracledb.readthedocs.io/en/latest/api_manual/pipeline.html#pipelineopresult-objects

        >>> results = await op.run_pipeline_async(pipeline, continue_on_error=True)
        >>> raise_if_failed(results)
    """
    failed = [(index, result) for index, result in enumerate(results)
              if result.error or (fail_on_warning and result.warning)]
    if failed:
        details = "\n".join(
            f"#{index}: {result.error or result.warning} | "
            f"{result.operation.statement or result.operation.name or result.operation.op_type}"
            for index, result in failed)
        raise QueryNotExecutedException(f"{len(failed)} pipeline operation(s) failed:\n{details}")


class PipelineOperational:

    def __init__(self, connection: AsyncConnection):
        """ connection: an asynchronous connection, e.g. WrapperConnection.create_connector(async_mode=True).
            python-oracledb only runs pipelines with asyncio:
            https://python-oracledb.readthedocs.io/en/latest/user_guide/asyncio.html#pipelining-database-operations
        """
        if not isinstance(connection, AsyncConnection):
            raise InvalidParameterException(
                "PipelineOperational needs an asynchronous connection (python-oracledb only runs pipelines "
                "with asyncio). Use WrapperConnection.create_connector(async_mode=True).")
        self.connection = connection

    def create_pipeline(self) -> oracle.Pipeline:
        """ Create an empty pipeline. Add operations with the add_* functions of this module or pipeline.add_*. """
        return oracle.create_pipeline()

    async def run_pipeline_async(self, /, pipeline: oracle.Pipeline, continue_on_error: bool = True,
                                 pool: oracle.AsyncConnectionPool | None = None) -> list[Any]:
        """ Run a pipeline and return the result of each operation.
            Uses a connection from pool when given (connector.create_pool()), otherwise opens a new one.
            Pipelining only works with AsyncConnection (python-oracledb limitation).

            For ingestion use continue_on_error=False: the pipeline stops at the first error,
            the commit is not reached and the uncommitted changes are rolled back.

            Example
            -------
            >>> op = PipelineOperational(async_connection)
            >>> pipeline = op.create_pipeline()
            >>> add_truncate(pipeline, "stg_users")
            >>> add_dataframe(pipeline, "stg_users", df)
            >>> add_count_duplicates(pipeline, "stg_users", ["id"])
            >>> add_merge(pipeline, "stg_users", "users", ["source.id = target.id"],
            ...           update_values={"name": "source.name"}, insert_values={"id": "source.id", "name": "source.name"})
            >>> pipeline.add_commit()
            >>> add_gather_stats(pipeline, "users")
            >>> results = await op.run_pipeline_async(pipeline, continue_on_error=False)
        """
        if pool is not None:
            async with pool.acquire() as connection:
                return await connection.run_pipeline(pipeline, continue_on_error=continue_on_error)

        connection = await self.connection._get_connection()
        if not connection:
            raise InvalidConnectionException('Connection is not available')
        async with connection:
            return await connection.run_pipeline(pipeline, continue_on_error=continue_on_error)
