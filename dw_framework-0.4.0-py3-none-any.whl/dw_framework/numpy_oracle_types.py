"""
    This module defines a mapping between NumPy data types and their corresponding 
    Oracle SQL data types. The `NUMPY_ORACLE_TYPE_MAP` dictionary serves as a 
    reference for converting various NumPy data types, including signed and unsigned 
    integers, floating-point numbers, complex numbers, booleans, byte strings, 
    unicode strings, and datetime types, into appropriate Oracle SQL types.
    
    The mapping is essential for applications that need to interface between 
    NumPy arrays and Oracle databases, ensuring that data types are correctly 
    translated to maintain data integrity and compatibility during data 
    storage and retrieval operations.
    
    Each entry in the mapping specifies the NumPy data type as the key and the 
    equivalent Oracle SQL data type as the value, facilitating seamless 
    interactions between Python applications using NumPy and Oracle databases.
    
    Mapping atualizado entre tipos pandas 3.x / NumPy e Oracle SQL.
    Inclui:
    - Strings modernas (Arrow, Python, object legado)
    - Tipos numéricos com suporte a nulos (nullable)
    - Tipos temporais, intervalos e periodos
    - Tipos especializados (category, interval, sparse)
    - Tipos NumPy clássicos
"""

NUMPY_ORACLE_TYPE_MAP = {
    # -----------------------------
    # Inteiros NumPy com sinal
    # -----------------------------
    "|i1": "NUMBER(3)", "<i1": "NUMBER(3)", ">i1": "NUMBER(3)",
    "|i2": "NUMBER(5)", "<i2": "NUMBER(5)", ">i2": "NUMBER(5)",
    "|i4": "NUMBER(10)", "<i4": "NUMBER(10)", ">i4": "NUMBER(10)",
    "|i8": "NUMBER(19)", "<i8": "NUMBER(19)", ">i8": "NUMBER(19)",

    # -----------------------------
    # Inteiros NumPy sem sinal
    # -----------------------------
    "|u1": "NUMBER(3)", "<u1": "NUMBER(3)", ">u1": "NUMBER(3)",
    "|u2": "NUMBER(5)", "<u2": "NUMBER(5)", ">u2": "NUMBER(5)",
    "|u4": "NUMBER(10)", "<u4": "NUMBER(10)", ">u4": "NUMBER(10)",
    "|u8": "NUMBER(20)", "<u8": "NUMBER(20)", ">u8": "NUMBER(20)",

    # -----------------------------
    # Flutuantes NumPy
    # -----------------------------
    "<f2": "NUMBER(15,5)", ">f2": "NUMBER(15,5)",
    "<f4": "NUMBER(15,5)", ">f4": "NUMBER(15,5)",
    "<f8": "NUMBER(38,10)", ">f8": "NUMBER(38,10)",

    # -----------------------------
    # Complexos
    # -----------------------------
    "<c8": "VARCHAR(4000)",
    ">c8": "VARCHAR(4000)",
    "<c16": "VARCHAR(4000)",
    ">c16": "VARCHAR(4000)",

    # -----------------------------
    # Booleanos
    # -----------------------------
    "|b1": "CHAR(1)", "<b1": "CHAR(1)", ">b1": "CHAR(1)",
    "bool": "CHAR(1)",

    # -----------------------------
    # Bytes e Strings
    # -----------------------------
    "|S": "RAW(2000)",
    "|U": "VARCHAR2(4000)",
    "|O": "VARCHAR2(4000)",
    "|V": "RAW(2000)",
    "object": "VARCHAR2(4000)",
    "object_": "VARCHAR2(4000)",
    "str": "VARCHAR2(4000)",

    # -----------------------------
    # Numéricos com nulos (pandas 3.x)
    # -----------------------------
    "boolean": "CHAR(1)",
    "int8": "NUMBER(3)",
    "int16": "NUMBER(5)",
    "int32": "NUMBER(10)",
    "int64": "NUMBER(19)",
    "float32": "NUMBER(15,5)",
    "float64": "NUMBER(38,10)",

    # -----------------------------
    # Temporais (datetime64)
    # -----------------------------

    # Ano apenas
    "datetime64[y]": "NUMBER(4)",

    # Mês ou Dia → data sem hora
    "datetime64[d]": "DATE",
    "period[M]": "DATE",

    # Hora / Minuto / Segundo → TIMESTAMP
    "datetime64[h]": "TIMESTAMP",
    "datetime64[m]": "TIMESTAMP",
    "datetime64[s]": "TIMESTAMP",

    # Microsegundos (equivalente ao <M8[us])
    "datetime64[ms]": "TIMESTAMP(3)",
    "datetime64[us]": "TIMESTAMP(6)",
    "datetime64[ns]": "TIMESTAMP(9)",

    # Equivalentes diretos do dtype NumPy
    "<m8[us]": "TIMESTAMP(6)",
    ">m8[us]": "TIMESTAMP(6)",
    "|m8[us]": "TIMESTAMP(6)",

    # Genéricos
    "datetime64": "TIMESTAMP",
    "datetime64[ns, UTC]": "TIMESTAMP WITH TIME ZONE",

    "timedelta64[ns]": "INTERVAL DAY TO SECOND",
    "timedelta64": "INTERVAL DAY TO SECOND",

    # -----------------------------
    # Especializados
    # -----------------------------
    "category": "VARCHAR2(4000)",
    "interval": "INTERVAL DAY TO SECOND",
    "sparse[float64]": "NUMBER(38,10)",

    # -----------------------------
    # Aliases NumPy adicionais
    # -----------------------------
    "|f2": "NUMBER(15,5)",
    "|f4": "NUMBER(15,5)",
    "|f8": "NUMBER(38,10)",

    "|c8": "VARCHAR2(4000)",
    "|c16": "VARCHAR2(4000)",

    # -----------------------------
    # Tipos diretos
    # -----------------------------
    "float16": "NUMBER(15,5)",
    "complex64": "VARCHAR2(4000)",
    "complex128": "VARCHAR2(4000)",

    # -----------------------------
    # pandas 3.x: nomes exatos do dtype (str(dtype))
    # -----------------------------
    "uint8": "NUMBER(3)",
    "uint16": "NUMBER(5)",
    "uint32": "NUMBER(10)",
    "uint64": "NUMBER(20)",

    "datetime64[s, UTC]": "TIMESTAMP WITH TIME ZONE",
    "datetime64[ms, UTC]": "TIMESTAMP WITH TIME ZONE",
    "datetime64[us, UTC]": "TIMESTAMP WITH TIME ZONE",
    "period[D]": "DATE",

    # Colunas baseadas em Arrow (ex.: read_parquet(dtype_backend="pyarrow"))
    "int32[pyarrow]": "NUMBER(10)",
    "int64[pyarrow]": "NUMBER(19)",
    "float[pyarrow]": "NUMBER(15,5)",
    "double[pyarrow]": "NUMBER(38,10)",
    "bool[pyarrow]": "CHAR(1)",
    "string[pyarrow]": "VARCHAR2(4000)",
    "large_string[pyarrow]": "VARCHAR2(4000)",
    "date32[day][pyarrow]": "DATE",
    "timestamp[us][pyarrow]": "TIMESTAMP(6)",
    "timestamp[ns][pyarrow]": "TIMESTAMP(9)",
}
