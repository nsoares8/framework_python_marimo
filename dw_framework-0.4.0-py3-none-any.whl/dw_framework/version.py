"""Single source of the framework version."""

__version__ = "0.4.0"
