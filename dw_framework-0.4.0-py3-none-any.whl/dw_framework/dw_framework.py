"""DataStore: high-level interface to the Oracle data warehouse."""

import datetime
import decimal
import numbers
import re
from typing import Any, LiteralString, final, override

import oracledb as oracle
import pandas as pd
import pyarrow as pa

from .core import Connection
from .data_store_type import DataStoreType
from .idw_framework import IDataStore, QueryRows, RowFactory
from .utils.agg_enums import Aggregation
from .utils.dataframe_types import dataframe_to_arrow, oracle_column_types
from .utils.exception import (
    InvalidConnectionException,
    InvalidOperatorException,
    InvalidOptionParameterException,
    InvalidParameterException,
    QueryNotExecutedException,
)
from .utils.sql_patterns import PARALLEL_HINT
from .utils.validation import as_dict, as_list, as_number, as_pair_lists, check_names


@final
class DataStore(IDataStore, Connection):
    """
    High-level interface to the Oracle data warehouse.

    Connection settings default to the environment variables SERVERNAME, PORT, UNAME,
    UPDW, SERVICE, TNS_DNS and ORA_PATH. Write methods return True or False; read
    methods return the rows and raise oracle.DatabaseError if the query fails.

    Parameters
    ----------
    buffer_size : int
        Rows transferred per round trip, for queries and writes. Default is 10000.
    timeout : float
        Seconds to wait when opening the network connection. Default is 60.0.
    query_timeout : float, optional
        Maximum seconds of each round trip to the database (running a query or reading a batch).
        Default None: no limit.
    tns_dns, config, host, port, username, password, service_name : str, optional
        Override the matching environment variable.

    Notes
    -----
    How LOBs and numbers are fetched are process-wide python-oracledb settings, not parameters
    (see utils.settings):
    - LOB columns (CLOB, BLOB) are fetched as str/bytes, so they can still be read after the
      connection is closed. Change with set_default("fetch_lobs", True).
    - Numbers are fetched as int/float. Change with set_default("fetch_decimals", True) to get Decimal.

    The methods that build a SELECT accept hints= (any Oracle optimizer hints) and parallel=
    (degree of parallelism; the object default is set with set_parallel). See "Hints e paralelismo"
    in the README.
    The fetch_lobs and fetch_decimal constructor parameters were removed;
    see "Migração para a versão 0.4.0" in the README.
    """

    def __init__(
        self,
        buffer_size=10000,
        timeout=60.0,
        tns_dns: str | None = None,
        config: str | None = None,
        *,
        host: str | None = None,
        port: str | None = None,
        username: str | None = None,
        password: str | None = None,
        service_name: str | None = None,
        query_timeout: float | None = None,
    ):
        super().__init__(
            buffer_size=buffer_size,
            timeout=timeout,
            tns_dns=tns_dns,
            config=config,
            host=host,
            port=port,
            username=username,
            password=password,
            service_name=service_name,
            query_timeout=query_timeout,
        )
        self.__parallel: int | None = None

    def _run_command(
        self, query: str, parameters: Any | None = None, input_sizes: Any | None = None, batch_size: int | None = None
    ) -> bool:
        """Run a DDL/DML command. Return False and print the error if it fails."""
        try:
            return self.execute(
                input_sizes=input_sizes, ddl_command=query, parameters=parameters, batch_size=batch_size
            )
        except (oracle.DatabaseError, oracle.DataError, QueryNotExecutedException) as exc:
            print("This error was thrown because ", exc)
            return False

    @staticmethod
    def _check_degree(degree) -> int:
        """Degree of parallelism: an integer >= 0 (0: no hint, 1: serial). Oracle ignores invalid hints silently."""
        if isinstance(degree, bool) or not isinstance(degree, numbers.Integral) or degree < 0:
            raise InvalidParameterException("parallel must be an integer >= 0 (0: no hint, 1: serial)")
        return int(degree)

    def _hint(self, hints: list[str] | str | None, parallel: int | None) -> str:
        """
        One optimizer-hint comment for a query block, or "" when there is nothing.
        Oracle reads only one hint comment per block, right after SELECT, so everything goes in it.
        parallel: None uses set_parallel(); 0 adds no hint; 1 forces serial; n > 1 runs with degree n.
        A PARALLEL hint in hints and parallel in the same call raise an error (one would cancel the other).
        """
        items = [hints] if isinstance(hints, str) else list(hints or [])
        items = [str(h).strip() for h in items if h is not None and str(h).strip()]
        if any("/*" in h or "*/" in h for h in items):
            raise InvalidParameterException("hints must not contain /* or */")
        has_parallel_hint = any(PARALLEL_HINT.search(h) for h in items)
        if has_parallel_hint and parallel is not None:
            raise InvalidParameterException("Use either parallel or a PARALLEL hint, not both")
        degree = self.__parallel if parallel is None else self._check_degree(parallel)
        if degree and not has_parallel_hint:
            items.insert(0, f"PARALLEL({degree})")
        return f"/*+ {' '.join(items)} */ " if items else ""

    def _select(self, select_list: str, hints: list[str] | str | None, parallel: int | None) -> str:
        """
        "SELECT <hint> <select_list>" for a query block built by the framework.
        A hint comment written at the start of select_list (the old way, e.g. columns=["/*+ FULL(c) */ a"])
        is merged into the same comment, because Oracle would ignore a second one.
        """
        items = [hints] if isinstance(hints, str) else list(hints or [])
        stripped = select_list.lstrip()
        if stripped.startswith("/*+") and "*/" in stripped:
            end = stripped.index("*/")
            items.append(stripped[3:end])
            select_list = stripped[end + 2 :].lstrip()
        return f"SELECT {self._hint(items, parallel)}{select_list}"

    # ---------------------------------------------------------------- configuration

    @staticmethod
    def _partition_clause(value: Any) -> str:
        """
        "day_20261025" -> PARTITION (day_20261025): a partition by its name (validated).
        date / datetime / integer -> PARTITION FOR (...): the partition that holds that value of the key,
        so the name is not needed (e.g. interval partitions named SYS_P...).
        """
        if isinstance(value, str):
            check_names(value)
            return f"PARTITION ({value})"
        # The text always comes from the built-in types (int, Decimal, date), never from a subclass's own
        # __format__/__str__, so a value can only become digits, dates and signs.
        if isinstance(value, datetime.datetime):  # before date: a datetime is also a date
            return f"PARTITION FOR (TIMESTAMP '{datetime.datetime.isoformat(value, ' ', 'seconds')[:19]}')"
        if isinstance(value, datetime.date):
            return f"PARTITION FOR (DATE '{datetime.date.isoformat(value)}')"
        if isinstance(value, numbers.Integral) and not isinstance(value, bool):
            return f"PARTITION FOR ({int(value)})"
        if isinstance(value, decimal.Decimal) and decimal.Decimal(value).is_finite():  # not NaN or Infinity
            return f"PARTITION FOR ({decimal.Decimal(value)})"
        raise InvalidParameterException(
            f"partition must be a partition name, a date or an integer, not {type(value).__name__}"
        )

    @classmethod
    def _apply_partition(cls, tables: list[str], partition: Any) -> list[str]:
        """
        Puts the partition after each table that has one, before its alias ("fct_trf t" -> "fct_trf PARTITION (p) t").
        partition: one value for a single table, or {table or alias: value} for several (the alias wins).
        """
        if partition is None:
            return tables
        if not isinstance(partition, dict):
            if len(tables) != 1:
                raise InvalidParameterException(
                    'With several tables, partition must be a dict {table or alias: partition}, e.g. {"t": "day_20261025"}'
                )
            partition = {tables[0].split()[0]: partition}
        wanted = {str(key).lower(): value for key, value in partition.items()}
        parts = [item.split(maxsplit=1) for item in tables]  # [name] or [name, alias]
        names = [part[0].lower() for part in parts]
        result = []
        for item, (name, *alias) in zip(tables, parts, strict=True):
            key = alias[0].lower() if alias and alias[0].lower() in wanted else name.lower()
            if key not in wanted:
                result.append(item)
                continue
            if not alias or alias[0].lower() != key:  # chosen by the table name
                if names.count(key) > 1:
                    raise InvalidParameterException(f"{name} appears more than once: use the aliases in partition")
            if "@" in name:
                raise InvalidParameterException(
                    f"{name}: Oracle does not accept a partition on a remote table (ORA-14100); "
                    "filter by the partition key in where"
                )
            result.append(" ".join([name, cls._partition_clause(wanted[key]), *alias]))
        used = {part[1].lower() for part in parts if len(part) > 1} | set(names)
        if unknown := sorted(set(wanted) - used):
            raise InvalidParameterException(
                f"partition: {', '.join(unknown)} is not a table or alias of the query ({', '.join(sorted(used))})"
            )
        return result

    def get_connection(self):
        return super()._get_connection()

    def set_parallel(self, degree: int | None) -> None:
        """
        Degree of parallelism for the queries built by the framework (not for query(), where you write the SQL).
        None (default): no PARALLEL hint; 1: serial; n > 1: degree n. Each method can override it with parallel=.
        """
        self.__parallel = None if degree is None else self._check_degree(degree)

    def get_parallel(self) -> int | None:
        """Degree of parallelism set with set_parallel (None: not set)."""
        return self.__parallel

    def set_timeout(self, timeout: int = 60):
        """Set the timeout in seconds."""
        if isinstance(timeout, int) and timeout > 0:
            self.timeout = timeout
        else:
            raise InvalidParameterException("Timeout must be an int greater than zero")

    def get_timeout(self):
        """Return the timeout in seconds."""
        return self.timeout

    def set_buffer(self, buffer_size):
        """Set how many rows are transferred per round trip to the database."""
        if isinstance(buffer_size, int) and buffer_size > 0:
            super().set_buffer(buffer_size=buffer_size)
        else:
            raise InvalidParameterException("buffer_size must be an int greater than zero")

    def get_buffer(self):
        return super().get_buffer()

    def version(self):
        return self.__version__

    @override
    def rewrite_connection(
        self,
        username: str | None = None,
        password: str | None = None,
        tns_dns: str | None = None,
        config: str | None = None,
        timeout: float | None = None,
    ) -> None:
        """Change the connection settings. Only the parameters passed are changed."""
        return super().rewrite_connection(username, password, tns_dns, config, timeout)

    # ---------------------------------------------------------------- queries

    def _data_factory(
        self,
        factoryrow: RowFactory,
        query_string: str,
        maxnumrows: int | None,
        offset: int = 0,
        columnar: bool = False,
        schema: Any = None,
        params: dict[str, Any] | None = None,
    ) -> QueryRows:
        """Run a SELECT and return the rows as DataStoreType (read row by row, or in Arrow columns with
        columnar), or built with factoryrow. params: the values of the :name binds of the SQL."""
        if callable(factoryrow):
            return self._execute_query(
                query_string=query_string, maxnumrows=maxnumrows, factoryrow=factoryrow, offset=offset, params=params
            )
        return DataStoreType(
            self._execute_query(
                query_string=query_string,
                maxnumrows=maxnumrows,
                offset=offset,
                columnar=columnar,
                schema=schema,
                params=params,
            )
        )

    def query(
        self,
        /,
        factoryrow: RowFactory = None,
        offset: int = 0,
        maxnumrows: int | None = 500,
        *,
        params: dict[str, Any] | None = None,
        query_string: str = "",
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Run a SELECT and return up to maxnumrows rows, skipping the first offset rows.
        With maxnumrows=None, returns every row (mind the memory on large tables).

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.query(query_string="SELECT * FROM users ORDER BY id", offset=100, maxnumrows=100)
        >>> dw.query(query_string="SELECT * FROM users", maxnumrows=None)   # all rows
        """
        if not query_string:
            raise InvalidParameterException("query_string must be defined")
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query_string,
            maxnumrows=maxnumrows,
            offset=offset,
            columnar=columnar,
            schema=schema,
        )

    def select(
        self,
        /,
        columns: list[str] | None = None,
        from_: list[str] | str | None = None,
        where: str = "1=1",
        groupby: list[str] | None = None,
        having: list[str] | None = None,
        orderby: list[str] | None = None,
        maxnumrows: int | None = 500,
        offset: int = 0,
        factoryrow: RowFactory = None,
        *,
        params: dict[str, Any] | None = None,
        partition: Any = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Build and run a SELECT. The having conditions are joined with AND.

        columnar=True: reads the result in Arrow columns straight from the driver (much faster and lighter
        for large results). Types follow the driver's data frame rules: a NUMBER without declared precision
        comes as float (about 15-16 digits); use schema (one pyarrow type per column) to keep the precision,
        or TO_CHAR for identifiers. Some types (ROWID, XMLTYPE) are not supported. Ignored with factoryrow.

        >>> dw.select(columns=["region", "SUM(amount) total"], from_="sales", groupby=["region"])
        >>> dw.select(from_="cdr_voz", maxnumrows=None, columnar=True).to_pandas()
        """
        from_, columns = as_list(from_, "from_"), as_list(columns, "columns")
        groupby, having, orderby = as_list(groupby, "groupby"), as_list(having, "having"), as_list(orderby, "orderby")
        if not from_:
            raise InvalidParameterException("from_ must be defined")
        tables = ", ".join(self._apply_partition(from_, partition))

        query = f"{self._select(', '.join(columns or ['*']), hints, parallel)} FROM {tables} WHERE {where}"
        if groupby:
            query += f" GROUP BY {', '.join(groupby)}"
        if having:
            query += f" HAVING {' AND '.join(having)}"
        if orderby:
            query += f" ORDER BY {', '.join(orderby)}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            offset=offset,
            columnar=columnar,
            schema=schema,
        )

    def query_as_oracle_data_frame(
        self,
        *,
        query_string: str = "",
        params: dict[str, Any] | None = None,
        buffer_size: int | None = None,
        schema: Any = None,
    ) -> Any:
        """
        Read the whole result into an Oracle DataFrame (PyArrow compatible). Fastest for large volumes.
        Without buffer_size, uses the buffer_size of the object (set_buffer).
        schema: optional pyarrow schema, one entry per column, to choose each Arrow type (requested_schema),
        e.g. pa.decimal128(38, 2) to keep the precision of a NUMBER without declared precision.
        params: the values of the :name binds of the SQL, as in the other reads.

        >>> pyarrow.table(dw.query_as_oracle_data_frame(query_string="SELECT * FROM users WHERE id = :id", params={"id": 1}))
        """
        return self.fetch_as_oracle_dataframe(
            buffer_size=buffer_size or self.get_buffer(),
            query_string=query_string,
            parameters=as_dict(params, "params"),
            schema=schema,
        )

    def query_batch_as_oracle_data_frame(
        self,
        *,
        query_string: str = "",
        params: dict[str, Any] | None = None,
        buffer_size: int | None = None,
        schema: Any = None,
    ) -> Any:
        """
        Read the result in batches of buffer_size rows. Only one batch is in memory at a time.
        Without buffer_size, uses the buffer_size of the object (set_buffer).
        schema: optional pyarrow schema to choose each Arrow type (see query_as_oracle_data_frame).
        params: the values of the :name binds of the SQL, as in the other reads.
        """
        return self.fetch_as_oracle_batch_dataframe(
            buffer_size=buffer_size or self.get_buffer(),
            query_string=query_string,
            schema=schema,
            parameters=as_dict(params, "params"),
        )

    def with_(
        self,
        cte_name: str,
        sql_stament: str | None = None,
        columns: list[str] | None = None,
        factoryrow: RowFactory = None,
        where: str = "1=1",
        maxnumrows: int | None = 500,
        *,
        params: dict[str, Any] | None = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Run WITH cte_name (columns) AS (sql_stament) SELECT * FROM cte_name WHERE where.

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.with_(cte_name="recent", sql_stament="SELECT * FROM sales WHERE sale_date >= SYSDATE - 30")
        """
        if not cte_name:
            raise InvalidParameterException("Cte must have a name")
        if not sql_stament:
            raise InvalidParameterException("Sql statment is required")
        columns = as_list(columns, "columns")
        header = f"{cte_name} ({', '.join(columns)})" if columns else cte_name
        query = f"WITH {header} AS ({sql_stament}) {self._select('*', hints, parallel)} FROM {cte_name} WHERE {where}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    def sample_data(
        self,
        /,
        partition=None,
        probability: int = 50,
        random_state: int | None = 42,
        blocks=True,
        maxnumrows: int | None = 500,
        where="1=1",
        *,
        params: dict[str, Any] | None = None,
        table_name: str | None = None,
        columns: list | None = None,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Extract a random sample with SAMPLE (rows) or SAMPLE BLOCK (blocks).
        random_state is the SEED: the same value returns the same sample; None returns a different one each time.

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.sample_data(table_name="customers", columns=["age", "income"], probability=5)
        """
        check_names(table_name)
        columns, probability = as_list(columns, "columns"), as_number(probability, "probability")
        if random_state is not None:
            random_state = as_number(random_state, "random_state")
        source = self._apply_partition([str(table_name)], partition)[0]
        query = f"{self._select(', '.join(columns or ['*']), hints, parallel)} FROM {source}"
        query += f" {'SAMPLE BLOCK' if blocks else 'SAMPLE'} ({probability})"
        if random_state is not None:
            query += f" SEED ({random_state})"  # same sample on every run
        query += f" WHERE {where}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    # ---------------------------------------------------------------- joins and set operations

    def _set_operation(
        self,
        operator: str,
        left_table,
        right_table,
        left_columns,
        right_columns,
        maxnumrows: int | None,
        factoryrow: RowFactory,
        hints=None,
        parallel=None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """Shared code of subset (INTERSECT), union and minus."""
        check_names(left_table, right_table)
        left_columns, right_columns = as_pair_lists(left_columns, right_columns, "left_columns", "right_columns")
        if not left_columns or not right_columns:
            raise InvalidParameterException("Left and right columns must be defined")
        if len(left_columns) != len(right_columns):
            raise InvalidParameterException("Columns length must be the same on both sides")

        query = (
            f"{self._select(', '.join(left_columns), hints, parallel)} FROM {left_table} {operator} "
            f"{self._select(', '.join(right_columns), hints, parallel)} FROM {right_table}"
        )
        return self._data_factory(
            factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows, columnar=columnar, schema=schema
        )

    def subset(
        self,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list[str] | None = None,
        right_columns: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Rows that exist in both tables (INTERSECT).
        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").
        """
        return self._set_operation(
            "INTERSECT",
            left_table,
            right_table,
            left_columns,
            right_columns,
            maxnumrows,
            factoryrow,
            hints,
            parallel,
            columnar,
            schema,
        )

    def union(
        self,
        keep_all=True,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list[str] | None = None,
        right_columns: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Rows of both tables: UNION ALL with keep_all=True, UNION with keep_all=False.
        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").
        """
        return self._set_operation(
            "UNION ALL" if keep_all else "UNION",
            left_table,
            right_table,
            left_columns,
            right_columns,
            maxnumrows,
            factoryrow,
            hints,
            parallel,
            columnar,
            schema,
        )

    def minus(
        self,
        /,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        left_columns: list | None = None,
        right_columns: list | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Rows of left_table that do not exist in right_table (MINUS).
        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").
        """
        return self._set_operation(
            "MINUS",
            left_table,
            right_table,
            left_columns,
            right_columns,
            maxnumrows,
            factoryrow,
            hints,
            parallel,
            columnar,
            schema,
        )

    def join(
        self,
        /,
        left_alias: str | None = "lt",
        right_alias: str | None = "rt",
        strategy="JOIN",
        column: list[str] | None = None,
        left_table: str | None = None,
        right_table: str | None = None,
        *,
        params: dict[str, Any] | None = None,
        partition: Any = None,
        on_left_columns: list[str] | None = None,
        on_right_columns: list[str] | None = None,
        where: str = "1=1",
        groupby: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Join two tables, pairing on_left_columns[i] with on_right_columns[i].
        on_left_columns / on_right_columns: lists (or tuples) of columns of the same length; two strings
        are taken as a single pair of columns. Anything else raises InvalidParameterException.
        strategy: JOIN, INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL JOIN or CROSS JOIN (no join columns).

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.join(left_table="customers", right_table="topups", strategy="LEFT JOIN",
        ...         on_left_columns=["msisdn"], on_right_columns=["msisdn"], column=["lt.msisdn", "rt.amount"])
        """
        check_names(left_table, right_table)
        if strategy not in ("JOIN", "LEFT JOIN", "RIGHT JOIN", "FULL JOIN", "INNER JOIN", "CROSS JOIN"):
            raise InvalidParameterException("Invalid strategy selected")
        left_alias = left_alias or "LT"
        right_alias = right_alias or "RT"
        column, groupby = as_list(column, "column"), as_list(groupby, "groupby")
        select_columns = ", ".join(column) if column else f"{left_alias}.*, {right_alias}.*"

        left, right = self._apply_partition(
            [f"{left_table} {left_alias or ''}".strip(), f"{right_table} {right_alias or ''}".strip()], partition
        )
        query = f"{self._select(select_columns, hints, parallel)} FROM {left} {strategy} {right}"
        if strategy != "CROSS JOIN":
            on_left_columns, on_right_columns = as_pair_lists(
                on_left_columns, on_right_columns, "on_left_columns", "on_right_columns"
            )
            if not on_left_columns or not on_right_columns:
                raise InvalidParameterException("Join columns must be defined")
            if len(on_left_columns) != len(on_right_columns):
                raise InvalidParameterException("Columns length must be the same on both sides")
            query += " ON " + " AND ".join(
                f"{left_alias}.{lc} = {right_alias}.{rc}"
                for lc, rc in zip(on_left_columns, on_right_columns, strict=True)
            )
        query += f" WHERE {where}"
        if groupby:
            query += f" GROUP BY {', '.join(groupby)}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    def natural_join(
        self,
        /,
        from_: list[str] | None = None,
        columns: list[str] | None = None,
        maxnumrows: int | None = 500,
        where: str = "1=1",
        groupby: list[str] | None = None,
        order_by: list[str] | None = None,
        factoryrow: RowFactory = None,
        *,
        params: dict[str, Any] | None = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        NATURAL JOIN of the tables in from_ (joins on every column with the same name).

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.natural_join(from_=["sales", "products"], columns=["sales_amount", "product_name"])
        """
        from_, columns = as_list(from_, "from_"), as_list(columns, "columns")
        groupby, order_by = as_list(groupby, "groupby"), as_list(order_by, "order_by")
        if not from_ or len(from_) < 2:
            raise InvalidParameterException("At least two tables must be provided for natural join")
        if not columns:
            raise InvalidParameterException("Columns must be provided as a list")

        query = f"{self._select(', '.join(columns), hints, parallel)} FROM {' NATURAL JOIN '.join(from_)} WHERE {where}"
        if groupby:
            query += f" GROUP BY {', '.join(groupby)}"
        if order_by:
            query += f" ORDER BY {', '.join(order_by)}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    def using_join(
        self,
        from_: list[str] | str | None,
        using: list[list[str] | str] | str | None = None,
        columns: list[str] | None = None,
        where: str = "1=1",
        groupby: list[str] | None = None,
        order_by: list[str] | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
        *,
        params: dict[str, Any] | None = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Join the tables in from_ with JOIN ... USING. using[i] holds the columns for the join with from_[i + 1].

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.using_join(from_=["sales", "products"], using=[["product_id"]], columns=["sales_amount"])
        """
        from_, columns = as_list(from_, "from_"), as_list(columns, "columns")
        groupby, order_by = as_list(groupby, "groupby"), as_list(order_by, "order_by")
        if not from_ or len(from_) < 2:
            raise InvalidParameterException("At least two tables must be provided for using join")
        using_items = as_list(using, "using", strings_only=False)
        if not using_items:
            raise InvalidParameterException("using must be a list of lists")
        using_lists = [as_list(columns_, "using") or [] for columns_ in using_items]  # "id" or ["id"] per table
        if len(using_lists) != len(from_) - 1 or not all(using_lists):
            raise InvalidParameterException(
                "using must have one list of columns for each joined table (len(from_) - 1)"
            )
        if not columns:
            raise InvalidParameterException("Columns must be provided as a list")

        first_table, *other_tables = from_  # without changing the caller's list
        query = f"{self._select(', '.join(columns), hints, parallel)} FROM {first_table}"
        for table, using_columns in zip(other_tables, using_lists, strict=True):
            query += f" JOIN {table} USING ({', '.join(using_columns)})"
        query += f" WHERE {where}"
        if groupby:
            query += f" GROUP BY {', '.join(groupby)}"
        if order_by:
            query += f" ORDER BY {', '.join(order_by)}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    # ---------------------------------------------------------------- aggregations

    def agg(
        self,
        /,
        table_name: str,
        columns: list[str] | str,
        aggregate_functions: list[dict],
        where: str = "1=1",
        factoryrow: RowFactory = None,
        maxnumrows: int | None = 500,
        *,
        params: dict[str, Any] | None = None,
        partition: Any = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        Apply aggregate functions to the whole table, or analytic functions with OVER.
        For GROUP BY use groupby(): columns plus aggregates without "over" raise ORA-00937.

        Each dict in aggregate_functions has:
        - aggregation_function: an Aggregation member or its name (e.g. Aggregation.SUM, "SUM", "sum")
        - agg_column: the column, "*" for COUNT, or two columns for CORR / COVAR_POP / COVAR_SAMP ("x, y")
        - option (optional): e.g. DISTINCT
        - over (optional): analytic clause, e.g. PARTITION BY region
        - alias (optional): name of the result. Default: <agg_column>_<function>, e.g. amount_sum.
          Two results with the same name raise an error, so set alias in one of them.

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.agg(table_name="sales", columns=["region"], aggregate_functions=[
        ...     {"aggregation_function": Aggregation.SUM, "agg_column": "amount", "over": "PARTITION BY region"},
        ...     {"aggregation_function": "SUM", "agg_column": "amount", "over": "PARTITION BY product",
        ...      "alias": "total_product"}])
        """
        check_names(table_name)
        specs = (
            [aggregate_functions]  # a single function
            if isinstance(aggregate_functions, dict)
            else as_list(aggregate_functions, "aggregate_functions", strings_only=False)
        )
        if not specs:
            raise InvalidParameterException("Aggregation function must be a list")
        if not all(isinstance(spec, dict) for spec in specs):
            raise InvalidParameterException("aggregate_functions must contain only dicts")
        select_parts = as_list(columns, "columns") or []
        names = set()
        for spec in specs:
            function, agg_column = spec.get("aggregation_function"), spec.get("agg_column")
            function = getattr(function, "value", function)  # Aggregation.SUM -> "SUM"
            if isinstance(function, str):
                function = function.upper()  # "sum" -> "SUM"
            if function not in Aggregation:
                raise InvalidOptionParameterException(f"Aggregation function not supported: {function}")
            if not agg_column:
                raise InvalidOptionParameterException("agg_column must be defined")

            option = f"{spec['option']} " if spec.get("option") else ""
            expression = f"{function}({option}{agg_column})"
            if spec.get("over"):
                expression += f" OVER ({spec['over']})"
            # result name: alias if given, otherwise column_function with only letters, digits and _
            alias = spec.get("alias") or (
                re.sub(r"\W+", "_", "all" if agg_column == "*" else agg_column).strip("_") + f"_{str(function).lower()}"
            )
            if alias.lower() in names:
                raise InvalidOptionParameterException(f"Duplicated result name {alias!r}: set 'alias' in one of them")
            names.add(alias.lower())
            select_parts.append(f"{expression} AS {alias}")

        query = f"{self._select(', '.join(select_parts), hints, parallel)} FROM {self._apply_partition([table_name], partition)[0]} WHERE {where}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    def groupby(
        self,
        /,
        maxnumrows: int | None = 500,
        table_name: str = "DUAL",
        columns: list[str] | None = None,
        aggregation_function: list | None = None,
        where: str = "1=1",
        groupby: list[str] | None = None,
        having: str | list[str] | None = None,
        order_by: str | list[str] | None = None,
        factoryrow: RowFactory = None,
        *,
        params: dict[str, Any] | None = None,
        partition: Any = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
        columnar: bool = False,
        schema: Any = None,
    ) -> QueryRows:
        """
        GROUP BY query. Without groupby, groups by columns.

        columnar / schema: read in Arrow columns (see select and the README, "Leitura em colunas").

        >>> dw.groupby(table_name="sales", columns=["region"], aggregation_function=["SUM(amount) total"],
        ...            having="SUM(amount) > 1000")
        """
        check_names(table_name)
        columns = as_list(columns, "columns") or []
        aggregation_function = as_list(aggregation_function, "aggregation_function") or []
        groupby = as_list(groupby, "groupby") or columns
        having, order_by = as_list(having, "having"), as_list(order_by, "order_by")
        if not columns and not aggregation_function:
            raise InvalidParameterException("columns or aggregation_function must be defined")

        query = f"{self._select(', '.join(columns + aggregation_function), hints, parallel)} FROM {self._apply_partition([table_name], partition)[0]} WHERE {where}"
        if groupby:
            query += f" GROUP BY {', '.join(groupby)}"
        if having:
            query += f" HAVING {' AND '.join(having)}"
        if order_by:
            query += f" ORDER BY {', '.join(order_by)}"
        return self._data_factory(
            params=params,
            factoryrow=factoryrow,
            query_string=query,
            maxnumrows=maxnumrows,
            columnar=columnar,
            schema=schema,
        )

    # ---------------------------------------------------------------- writing data

    def execute(
        self,
        /,
        input_sizes: int | tuple | None = None,
        ddl_command: str | None = "",
        parameters: list | dict | tuple | None = None,
        *,
        batch_size: int | None = None,
    ) -> bool:
        """
        Run any DDL or DML command in its own transaction.
        parameters: rows for executemany (list, pandas DataFrame or Arrow table), sent in blocks of
        batch_size rows (default: all at once); any rejected row rolls back everything.
        Raises QueryNotExecutedException if the server did not execute it.
        """
        result = self._dml_or_ddl_executor(
            ddl_command=ddl_command or "", parameters=parameters, input_sizes=input_sizes, batch_size=batch_size
        )
        if not result:
            raise QueryNotExecutedException("Query was not executed by the server")
        return result

    def insert(
        self,
        input_sizes: tuple | None = None,
        /,
        *,
        table: str = "",
        columns: list | None = None,
        values: list[tuple] | pa.Table | None = None,
        batch_size: int | None = None,
    ) -> bool:
        """
        Insert one or many rows with binds and executemany. False on error (nothing is saved).
        values: list of tuples or an Arrow table; batch_size: rows per block (default: all at once).

        >>> dw.insert(table='users', columns=['name', 'age'], values=[('Alice', 30), ('Bob', 25)])
        True
        """
        columns = as_list(columns, "columns")
        check_names(table, *(columns or []))  # column names, not expressions
        if values is None or len(values) == 0:
            raise InvalidParameterException("values not defined")

        total = len(columns) if columns else (values.num_columns if isinstance(values, pa.Table) else len(values[0]))
        binds = ", ".join(f":{index}" for index in range(1, total + 1))
        target_columns = f" ({', '.join(columns)})" if columns else ""
        return self._run_command(
            f"INSERT INTO {table}{target_columns} VALUES ({binds})",
            parameters=values,
            input_sizes=input_sizes,
            batch_size=batch_size,
        )

    def load_into_database(
        self,
        *,
        data_frame: pd.DataFrame | None = None,
        table_name: str = "",
        columns: list | None = None,
        inputsize: tuple[int, ...] | None = None,
        batch_size: int | None = None,
        direct: bool = False,
        method: str = "auto",
    ) -> bool:
        """
        Insert the rows of a DataFrame into an existing table. Without columns, uses every DataFrame column.
        NaN/NaT become NULL. Rows are sent in blocks of batch_size (default: the object's buffer_size).

        direct=False (default): one transaction, all or nothing.
        direct=True: direct-path load, much faster for large volumes and with minimal redo, but the rows are
        committed by the load itself (no rollback) and the table is locked during the load: use it for new
        or staging tables. method chooses how:
        - "auto" (default): the driver Direct Path Load when available, otherwise APPEND_VALUES;
        - "direct_path": driver Direct Path Load API (python-oracledb 3.4+, Thin mode, Oracle 12.1+);
        - "append_values": INSERT /*+ APPEND_VALUES */ in blocks, one commit per block (Oracle 11.2+, any mode).

        >>> dw.load_into_database(data_frame=df, table_name='users_new')
        True
        """
        if not isinstance(data_frame, pd.DataFrame):
            raise InvalidParameterException("data_frame must be a pandas DataFrame")
        columns = as_list(columns, "columns") or data_frame.columns.to_list()
        check_names(table_name, *columns)
        data = dataframe_to_arrow(data_frame[columns])
        if direct:
            return self._bulk_load(table_name, columns, data, batch_size, method)
        return self.insert(
            inputsize, table=table_name, columns=columns, values=data, batch_size=batch_size or self.get_buffer()
        )

    def load_partitions(
        self,
        *,
        table_name: str,
        partitions: dict[str, pd.DataFrame] | None,
        columns: list | None = None,
        batch_size: int | None = None,
        workers: int = 4,
    ) -> dict[str, bool]:
        """
        Load several partitions of the same table at the same time (direct path, one thread per partition).

        Why it exists: direct_path_load and load_into_database(direct=True) take an exclusive lock on the
        whole table, so several partitions of the same table cannot be loaded in parallel with them.
        A direct-path INSERT into a named partition (INSERT /*+ APPEND_VALUES */ INTO t PARTITION (p))
        takes the exclusive lock only on that partition, so each partition can have its own thread.
        Useful to reload several days of a table partitioned by date; loading a single partition gains
        nothing over load_into_database(direct=True).

        partitions: {partition name: DataFrame with the rows of that partition}. Oracle rejects rows that
        do not belong to the partition (ORA-14401). All DataFrames must have the same columns.
        Returns {partition: True/False}. Each partition is independent and committed block by block:
        a failed partition may keep the blocks committed before the error. Oracle 11.2+, Thin or Thick.

        >>> dw.load_partitions(table_name="dw.cdr_voz", partitions={"P20261018": df_18, "P20261019": df_19}, workers=2)
        {'P20261018': True, 'P20261019': True}
        """
        partitions = as_dict(partitions, "partitions")
        if not partitions:
            raise InvalidParameterException("partitions must be defined")
        if not all(isinstance(df, pd.DataFrame) for df in partitions.values()):
            raise InvalidParameterException("partitions must map each partition name to a pandas DataFrame")
        columns = as_list(columns, "columns") or next(iter(partitions.values())).columns.to_list()
        check_names(table_name, *partitions, *columns)
        data = {partition: dataframe_to_arrow(df[columns]) for partition, df in partitions.items()}
        return self._load_partitions(table_name, data, columns, batch_size, workers)

    def load_data_frame(
        self,
        /,
        table_space_name: str = "DW_USERS",
        compression: str = "QUERY LOW",
        *,
        dataframe: pd.DataFrame,
        table_name: str = "",
        inputsize: tuple | None = None,
        batch: bool = False,
        chunksize: int | None = None,
    ) -> bool:
        """
        Create a table from the DataFrame types and load the data with Oracle Direct Path Load (fast, minimal redo).
        All or nothing: if the load fails, the new table is dropped.
        With batch=True, rows are sent in blocks of chunksize (default: the object's buffer_size).

        >>> dw.load_data_frame(dataframe=df, table_name='my_table')
        True
        """
        if not isinstance(dataframe, pd.DataFrame):
            raise InvalidParameterException("dataframe must be a pandas dataframe")

        types = oracle_column_types(dataframe)
        columns = [str(column).lower() for column in types]
        column_types = list(types.values())

        if not self.create_table(
            table_space_name, compression, table_name=table_name, columns=columns, column_type=column_types
        ):
            return False

        loaded = self.load_into_database(
            data_frame=dataframe,
            table_name=table_name,
            inputsize=inputsize,
            batch_size=(chunksize or self.get_buffer()) if batch else None,
            direct=True,
        )
        if not loaded:
            self.drop_table(table_name=table_name)  # no half-loaded table left behind
        return loaded

    @staticmethod
    def _where(where: dict | None, ari: str, operator: str, binds: dict) -> str:
        """WHERE clause with binds from a {column: value} dict, shared by update and delete.
        where=None means every row, on purpose; an empty dict raises, to avoid it by accident."""
        if ari not in (">", "<", "=", ">=", "<="):
            raise InvalidOperatorException("Invalid operator, '>', '<', '=', '>=', '<=' are accepted")
        if where is None:
            return ""
        if not isinstance(where, dict):
            raise TypeError("Where should be dict with values pairs")
        if not where:
            raise InvalidParameterException("where is empty: pass where=None to affect every row")
        conditions = []
        for column, value in where.items():
            if value is None and ari == "=":
                conditions.append(f"{column} IS NULL")  # "= NULL" is never true in Oracle
            else:
                conditions.append(f"{column} {ari} :where_{column}")
                binds[f"where_{column}"] = value
        return " WHERE " + f" {operator} ".join(conditions)

    def update(
        self, /, where: dict | None = None, ari: str = "=", operator="AND", *, table="", keyvalues: dict | None = None
    ) -> bool:
        """
        UPDATE table SET col = value ... WHERE col <ari> value. ari only applies to where.

        >>> dw.update(table='users', keyvalues={'age': 31}, where={'name': 'Alice'})
        True
        """
        check_names(table)
        if not isinstance(keyvalues, dict) or not keyvalues:
            raise TypeError("Key value should be defined as dict")

        binds = {f"keyvalues_{column}": value for column, value in keyvalues.items()}
        set_clause = ", ".join(f"{column} = :keyvalues_{column}" for column in keyvalues)
        query = f"UPDATE {table} SET {set_clause}" + self._where(where, ari, operator, binds)
        return self._run_command(query, parameters=[binds])

    def delete(self, operator: str = "AND", ari: str = "=", *, table="", where: dict | None = None) -> bool:
        """
        DELETE FROM table WHERE col <ari> value. Without where, deletes every row.

        >>> dw.delete(table='users', where={'name': 'Bob'})
        True
        """
        check_names(table)
        binds: dict[str, Any] = {}
        query = f"DELETE FROM {table}" + self._where(where, ari, operator, binds)
        return self._run_command(query, parameters=[binds] if binds else None)

    def merge(
        self,
        source: str | None,
        target: str | None = None,
        on_: list[str] | None = None,
        update_values: dict[str, str] | None = None,
        insert_values: dict[str, str] | None = None,
        delete_condition: str | None = None,
        target_alias: str = "target",
        source_alias: str = "source",
    ) -> bool:
        """
        MERGE INTO target USING source ON (on_) WHEN MATCHED THEN UPDATE ... WHEN NOT MATCHED THEN INSERT ...
        Values are SQL expressions; columns in on_ cannot be in update_values (ORA-38104).

        >>> dw.merge(source='staging_table', target='main_table', on_=['source.id = target.id'],
        ...          update_values={'name': 'source.name'}, insert_values={'id': 'source.id', 'name': 'source.name'})
        True
        """
        on_ = as_list(on_, "on_")
        update_values, insert_values = as_dict(update_values, "update_values"), as_dict(insert_values, "insert_values")
        if not source or not target or not on_:
            raise InvalidParameterException("Source, target and on conditions must be defined")
        if not update_values and not insert_values:
            raise InvalidParameterException("update_values or insert_values must be defined")
        if delete_condition and not update_values:
            raise InvalidOptionParameterException("In Oracle, DELETE in MERGE requires UPDATE.")
        alias = target_alias or target

        query = f"MERGE INTO {target} {target_alias} USING {source} {source_alias} ON ({' AND '.join(on_)})"
        if update_values:
            query += " WHEN MATCHED THEN UPDATE SET " + ", ".join(
                f"{alias}.{column} = {value}" for column, value in update_values.items()
            )
            if delete_condition:
                query += f" DELETE WHERE {delete_condition}"
        if insert_values:
            query += (
                f" WHEN NOT MATCHED THEN INSERT ({', '.join(insert_values)})"
                f" VALUES ({', '.join(map(str, insert_values.values()))})"
            )
        return self._run_command(query)

    # ---------------------------------------------------------------- tables and partitions

    def create_table(
        self,
        /,
        table_space_name: str | None = "DW_USERS",
        compression: str | None = "QUERY LOW",
        *,
        table_name: str | None = None,
        columns: list | None = None,
        column_type: list | None = None,
    ) -> bool:
        """
        Create an empty table; columns[i] gets the type column_type[i].

        >>> dw.create_table(table_name='users_new', columns=['name', 'age'], column_type=['VARCHAR2(100)', 'NUMBER'])
        True
        """
        if not columns or not column_type or len(columns) != len(column_type):
            raise InvalidParameterException("columns and column_type must be lists with the same size")
        check_names(table_name, *columns)

        fields = ", ".join(f"{column} {data_type}" for column, data_type in zip(columns, column_type, strict=True))
        query = f"CREATE TABLE {table_name} ({fields})"
        if table_space_name:
            query += f" TABLESPACE {table_space_name}"
        if compression:
            query += f" COMPRESS FOR {compression}"
        return self._run_command(query)

    def create_table_from_select(
        self,
        /,
        table_space_name: str = "DW_USERS",
        compression: str = "QUERY LOW",
        is_exraid: bool = True,
        *,
        table_name: str | None = None,
        statment: str = "",
        parallel: int | None = None,
    ) -> bool:
        """
        CREATE TABLE ... NOLOGGING PARALLEL COMPRESS [FOR compression] TABLESPACE ... AS statment.
        Without is_exraid or compression, uses basic COMPRESS.
        The table is created in parallel (fast) and then left with the degree for later queries:
        parallel=None (default) or 1: NOPARALLEL; n > 1: PARALLEL n. A table left with PARALLEL would make
        every query on it run in parallel by default, with the database default degree.

        >>> dw.create_table_from_select(table_name="tmp_active", statment="SELECT * FROM customers")
        True
        """
        check_names(table_name)
        if not statment:
            raise InvalidParameterException("statment should be defined")
        if not table_space_name:
            raise InvalidParameterException("table_space_name should be defined")
        degree = None if parallel is None else self._check_degree(parallel)

        compress = f"COMPRESS FOR {compression}" if is_exraid and compression else "COMPRESS"
        if not self._run_command(
            f"CREATE TABLE {table_name} NOLOGGING PARALLEL {compress} TABLESPACE {table_space_name} AS {statment}"
        ):
            return False
        return self._run_command(
            f"ALTER TABLE {table_name} {f'PARALLEL {degree}' if degree and degree > 1 else 'NOPARALLEL'}"
        )

    @staticmethod
    def _check_view(view_name: str, statement: str | None = None) -> None:
        """Shared checks of the view functions: a valid local name and, when creating, a statement."""
        check_names(view_name)
        if "@" in view_name:
            raise InvalidParameterException("A view cannot be created or changed through a database link")
        if statement is not None and not statement.strip():
            raise InvalidParameterException("statement must be a SELECT")

    def create_view(
        self,
        *,
        view_name: str,
        statement: str,
        columns: list[str] | str | None = None,
        replace: bool = False,
        read_only: bool = False,
        force: bool = False,
    ) -> bool:
        """
        CREATE [OR REPLACE] [FORCE] VIEW view_name [(columns)] AS statement [WITH READ ONLY].

        replace: changes an existing view and keeps its grants (DROP + CREATE would lose them).
        read_only: no INSERT, UPDATE or DELETE through the view.
        force: creates the view even if a table it reads does not exist yet (it stays invalid until it does).
        statement is a SELECT written by the user; a view cannot have binds (filter with params when reading it).

        >>> dw.create_view(view_name="dw.v_trafego_diario", replace=True,
        ...                statement="SELECT dia, msisdn, SUM(valor) total FROM fct_trf GROUP BY dia, msisdn")
        True
        """
        self._check_view(view_name, statement)
        names = as_list(columns, "columns") or []
        if names:
            check_names(*names)
        query = (
            f"CREATE {'OR REPLACE ' if replace else ''}{'FORCE ' if force else ''}VIEW {view_name}"
            f"{' (' + ', '.join(names) + ')' if names else ''} AS {statement.strip().rstrip(';')}"
            f"{' WITH READ ONLY' if read_only else ''}"
        )
        return self._run_command(query)

    def drop_view(self, *, view_name: str) -> bool:
        """DROP VIEW (the data stays in the tables the view reads)."""
        self._check_view(view_name)
        return self._run_command(f"DROP VIEW {view_name}")

    _MV_REFRESH = {"complete": "C", "fast": "F", "force": "?"}  # refresh method -> DBMS_MVIEW.REFRESH code

    def create_materialized_view(
        self,
        *,
        view_name: str,
        statement: str,
        columns: list[str] | str | None = None,
        refresh: str = "complete",
        on: str = "demand",
        build: str = "immediate",
        query_rewrite: bool = False,
    ) -> bool:
        """
        CREATE MATERIALIZED VIEW: the result of statement is stored, like a table, and refreshed when asked.

        refresh: "complete" (runs the SELECT again), "fast" (applies only the changes; needs materialized view
            logs on the tables it reads) or "force" (fast when possible, complete otherwise).
        on: "demand" (refresh_materialized_view refreshes it) or "commit" (after each commit on the tables).
        build: "immediate" (fills it now) or "deferred" (empty until the first refresh).
        query_rewrite: Oracle may answer queries on the tables with the stored result.
        Oracle has no OR REPLACE for materialized views: to change one, drop it and create it again.

        >>> dw.create_materialized_view(view_name="dw.mv_trafego_diario",
        ...     statement="SELECT dia, SUM(valor) total FROM fct_trf GROUP BY dia")
        True
        """
        self._check_view(view_name, statement)
        refresh, on, build = refresh.lower(), on.lower(), build.lower()
        if refresh not in self._MV_REFRESH:
            raise InvalidParameterException('refresh must be "complete", "fast" or "force"')
        if on not in ("demand", "commit"):
            raise InvalidParameterException('on must be "demand" or "commit"')
        if build not in ("immediate", "deferred"):
            raise InvalidParameterException('build must be "immediate" or "deferred"')
        names = as_list(columns, "columns") or []
        if names:
            check_names(*names)
        query = (
            f"CREATE MATERIALIZED VIEW {view_name}{' (' + ', '.join(names) + ')' if names else ''}"
            f" BUILD {build.upper()} REFRESH {refresh.upper()} ON {on.upper()}"
            f"{' ENABLE QUERY REWRITE' if query_rewrite else ''} AS {statement.strip().rstrip(';')}"
        )
        return self._run_command(query)

    def refresh_materialized_view(self, *, view_name: str, method: str = "complete", atomic: bool = True) -> bool:
        """
        Refreshes a materialized view (DBMS_MVIEW.REFRESH). method: "complete", "fast" or "force".
        atomic=True keeps the old data visible until the refresh ends; atomic=False is faster on a complete
        refresh (TRUNCATE + direct-path insert), but the view is empty while it runs.

        >>> dw.refresh_materialized_view(view_name="dw.mv_trafego_diario")
        True
        """
        self._check_view(view_name)
        code = self._MV_REFRESH.get(method.lower())
        if code is None:
            raise InvalidParameterException('method must be "complete", "fast" or "force"')
        # the name was validated (letters, digits, _ $ # and .), so it can go between quotes
        return self._run_command(
            f"BEGIN DBMS_MVIEW.REFRESH(list => '{view_name}', method => '{code}', "
            f"atomic_refresh => {'TRUE' if atomic else 'FALSE'}); END;"
        )

    def drop_materialized_view(self, *, view_name: str, preserve_table: bool = False) -> bool:
        """DROP MATERIALIZED VIEW; preserve_table=True keeps the stored data as an ordinary table."""
        self._check_view(view_name)
        return self._run_command(f"DROP MATERIALIZED VIEW {view_name}" + (" PRESERVE TABLE" if preserve_table else ""))

    def drop_table(self, /, purge=True, *, table_name=None) -> bool:
        """DROP TABLE, with PURGE by default (the table cannot be recovered)."""
        check_names(table_name)
        return self._run_command(f"DROP TABLE {table_name}" + (" PURGE" if purge else ""))

    def truncate_table(self, /, *, table_name=None) -> bool:
        """TRUNCATE TABLE."""
        check_names(table_name)
        return self._run_command(f"TRUNCATE TABLE {table_name}")

    def truncate_partition(self, table_name: str, partition_name: str) -> bool:
        """ALTER TABLE ... TRUNCATE PARTITION."""
        check_names(table_name, partition_name)
        return self._run_command(f"ALTER TABLE {table_name} TRUNCATE PARTITION {partition_name}")

    @staticmethod
    def _owner_and_table(table_name: str, owner: str | None) -> tuple[str | None, str, str]:
        """
        'dw.vendas@dw_link' -> ('DW', 'VENDAS', '@DW_LINK'); without a database link the last item is ''.
        The owner parameter wins over the owner in the name.
        """
        name, at, link = table_name.upper().partition("@")
        name_owner, _, name = name.rpartition(".")
        return (owner.upper() if owner else name_owner or None), name, at + link

    def get_columns_tables(
        self,
        *,
        table_name: str | None = None,
        owner: str | None = None,
        factoryrow: RowFactory = None,
        maxnumrows: int | None = 500,
    ) -> QueryRows:
        """
        Column metadata from ALL_TAB_COLUMNS, ordered by owner and column position.
        The owner comes from the owner parameter or from the name ("dw.vendas"); without it,
        the table is searched in every schema you can access (see the OWNER column).

        >>> dw.get_columns_tables(table_name="dw.vendas")
        >>> dw.get_columns_tables(table_name="vendas", owner="dw")
        """
        check_names(table_name, *([owner] if owner else []))
        owner, name, link = self._owner_and_table(str(table_name), owner)
        query = (
            "SELECT OWNER, TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NUM_DISTINCT, DENSITY "
            f"FROM ALL_TAB_COLUMNS{link} WHERE TABLE_NAME = '{name}'"
        )
        if owner:
            query += f" AND OWNER = '{owner}'"
        query += " ORDER BY OWNER, COLUMN_ID"
        return self._data_factory(factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows)

    def get_table_shape(
        self,
        table_name="DUAL",
        *,
        partition: Any = None,
        exact: bool = True,
        owner: str | None = None,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
    ) -> QueryRows:
        """
        Number of rows of a table, or of one partition.
        exact=True (default): COUNT(1); with partition, only that partition is read. Without a degree
        (parallel or set_parallel), uses the database default degree (PARALLEL).
        exact=False: NUM_ROWS from the statistics (instant). STALE_STATS = 'YES' means outdated; an empty
        total means the statistics were never gathered.

        >>> dw.get_table_shape("dw.cdr_voz", partition="P20261019")
        >>> dw.get_table_shape("dw.cdr_voz", exact=False)
        """
        check_names(table_name, *([owner] if owner else []))
        owner, name, link = self._owner_and_table(table_name, owner)
        if not exact:
            if partition is not None and not isinstance(partition, str):
                raise InvalidParameterException("exact=False needs the partition name (see table_partitions)")
            if partition:
                check_names(partition)
            level = "PARTITION" if partition else "TABLE"
            query = (
                "SELECT OWNER, PARTITION_NAME, NUM_ROWS total, LAST_ANALYZED, STALE_STATS "
                f"FROM ALL_TAB_STATISTICS{link} WHERE TABLE_NAME = '{name}' AND OBJECT_TYPE = '{level}'"
            )
            if partition:
                query += f" AND PARTITION_NAME = '{partition.upper()}'"
            if owner:
                query += f" AND OWNER = '{owner}'"
            return self.query(query_string=query)

        source = self._apply_partition([f"{owner + '.' if owner else ''}{name}{link}"], partition)[0]
        base = ["NO_REWRITE"] if parallel is not None or self.__parallel is not None else ["NO_REWRITE", "PARALLEL"]
        extra = [hints] if isinstance(hints, str) else list(hints or [])
        return self.query(query_string=f"{self._select('COUNT(1) total', base + extra, parallel)} FROM {source}")

    def table_partitions(
        self,
        /,
        condition="1=1",
        *,
        table_name="DUAL",
        owner: str | None = None,
        maxnumrows: int | None = 500,
        factoryrow: RowFactory = None,
    ) -> QueryRows:
        """
        Partitions of a table from ALL_TAB_PARTITIONS, filtered by condition and ordered by position.
        The owner comes from the owner parameter or from the name ("dw.vendas"); without it,
        the table is searched in every schema you can access (see the TABLE_OWNER column).

        >>> dw.table_partitions(table_name='dw.sales', condition="PARTITION_NAME LIKE 'P2024%'")
        """
        check_names(table_name, *([owner] if owner else []))
        owner, name, link = self._owner_and_table(table_name, owner)
        query = f"SELECT * FROM ALL_TAB_PARTITIONS{link} WHERE TABLE_NAME = '{name}'"
        if owner:
            query += f" AND TABLE_OWNER = '{owner}'"
        query += f" AND ({condition or '1=1'}) ORDER BY TABLE_OWNER, PARTITION_POSITION"
        return self._data_factory(factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows)

    def partition_key(self, table_name: str, owner: str | None = None) -> QueryRows:
        """
        The partition key columns of a table: filter by them in where to read a range of partitions
        (Oracle reads only the partitions needed).

        >>> dw.partition_key("dw.fct_trf")
        """
        check_names(table_name, *([owner] if owner else []))
        owner, name, link = self._owner_and_table(table_name, owner)
        query = (
            "SELECT OWNER, NAME TABLE_NAME, COLUMN_NAME, COLUMN_POSITION "
            f"FROM ALL_PART_KEY_COLUMNS{link} WHERE NAME = '{name}' AND OBJECT_TYPE = 'TABLE'"
        )
        if owner:
            query += f" AND OWNER = '{owner}'"
        return self.query(query_string=query + " ORDER BY OWNER, COLUMN_POSITION")

    def exchange_partition(
        self,
        /,
        options: str | None = None,
        *,
        left_table: str | None = None,
        right_table: str | None = None,
        partition: str | None = None,
    ) -> bool:
        """
        ALTER TABLE left_table EXCHANGE PARTITION partition WITH TABLE right_table [options].
        options: INCLUDING/EXCLUDING INDEXES, WITH/WITHOUT VALIDATION, UPDATE GLOBAL INDEXES.

        >>> dw.exchange_partition('WITHOUT VALIDATION', left_table='sales', right_table='stg', partition='P1')
        True
        """
        check_names(left_table, right_table, partition)
        query = f"ALTER TABLE {left_table} EXCHANGE PARTITION {partition} WITH TABLE {right_table}"
        if options:
            query += f" {options}"
        return self._run_command(query)

    def split_partition(
        self,
        /,
        value: tuple[str, ...] | None = None,
        at: str | None = None,
        *,
        table_name: str,
        partition: str,
        other_partition: list[dict],
        options: str | None = None,
    ) -> bool:
        """
        ALTER TABLE ... SPLIT PARTITION ... AT (at) | VALUES (value) INTO (two partitions) [options].

        >>> dw.split_partition(at="DATE '2024-07-01'", table_name='sales', partition='P2024',
        ...                    other_partition=[{"name": "P2024_H1"}, {"name": "P2024_H2"}])
        True
        """
        check_names(table_name, partition)
        if bool(at) == bool(value):
            raise InvalidParameterException("Provide either 'at' or 'value'")
        if not isinstance(other_partition, list) or len(other_partition) != 2:
            raise InvalidParameterException("other_partition must be a list with exactly two elements")

        if not at:
            values = as_list(value, "value", strings_only=False) or []  # "x" or ("x", "y")
            value_text = ", ".join(map(str, values))  # numbers are valid values too
        split_clause = f"AT ({at})" if at else f"VALUES ({value_text})"
        into = ", ".join(
            f"PARTITION {p['name']}" + (f" TABLESPACE {p['tablespace']}" if p.get("tablespace") else "")
            for p in other_partition
        )
        query = f"ALTER TABLE {table_name} SPLIT PARTITION {partition} {split_clause} INTO ({into})"
        if options:
            query += f" {options}"
        return self._run_command(query)

    # ---------------------------------------------------------------- PL/SQL

    @override
    def eprocedure(
        self,
        /,
        cursor: oracle.Cursor | None = None,
        procedure_name: LiteralString = "",
        parameters: list[Any] | None = None,
    ) -> Any:
        """Run a stored procedure with the given cursor. The caller commits."""
        if not cursor:
            raise InvalidConnectionException("Invalid cursor due to 'Null' value")
        if not procedure_name:
            raise InvalidParameterException("Procedure name must be defined")
        return self._procedure(cursor, procedure_name, parameters)

    @override
    def efunction(
        self,
        /,
        cursor: oracle.Cursor | None = None,
        function_name: LiteralString = "",
        parameters: list[Any] | None = None,
        output_type: type | None = None,
    ) -> Any:
        """Run a stored function with the given cursor and return its result."""
        if not cursor:
            raise InvalidConnectionException("Invalid cursor due to 'Null' value")
        if not function_name:
            raise InvalidParameterException("Function name must be defined")
        return self._function(cursor, function_name, parameters, output_type=output_type)

    # ---------------------------------------------------------------- statistics

    def pearson_correlaction(
        self,
        *,
        left_column: str = "",
        right_column: str = "",
        table_name="DUAL",
        factoryrow: RowFactory = None,
        maxnumrows: int | None = 1,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
    ) -> QueryRows:
        """Pearson correlation (CORR) between two numeric columns, from -1 to +1."""
        if not left_column or not right_column:
            raise InvalidParameterException("left and right columns must be defined")
        check_names(table_name)
        query = f"{self._select(f'CORR({left_column}, {right_column})', hints, parallel)} FROM {table_name}"
        return self._data_factory(factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows)

    def one_sample_t_test(
        self,
        /,
        musTresume: bool = True,
        method: str = "ONE_SIDED_SIG",
        *,
        column_name: str = "",
        table_name: str = "",
        sample_mean: int = 1,
        factoryrow: RowFactory = None,
        maxnumrows: int | None = 1,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
    ) -> QueryRows:
        """
        One-sample t-test (STATS_T_TEST_ONE). musTresume=True returns mean, both significances and t;
        False returns only method: STATISTIC, DF, ONE_SIDED_SIG or TWO_SIDED_SIG.
        """
        if not column_name:
            raise InvalidParameterException("column must be defined")
        check_names(table_name)
        sample_mean = as_number(sample_mean, "sample_mean")
        if musTresume:
            query = (
                f"{self._select(f'AVG({column_name}) group_mean,', hints, parallel)} "
                f"STATS_T_TEST_ONE({column_name}, {sample_mean}, 'ONE_SIDED_SIG') pvalue, "
                f"STATS_T_TEST_ONE({column_name}, {sample_mean}, 'TWO_SIDED_SIG') two_sided_p_value, "
                f"STATS_T_TEST_ONE({column_name}, {sample_mean}, 'STATISTIC') t_observed "
                f"FROM {table_name}"
            )
        else:
            if method not in ("STATISTIC", "DF", "ONE_SIDED_SIG", "TWO_SIDED_SIG"):
                raise TypeError("Value type does not exists")
            query = f"{self._select(f"STATS_T_TEST_ONE({column_name}, {sample_mean}, '{method}')", hints, parallel)} FROM {table_name}"
        return self._data_factory(factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows)

    def one_way_anova(
        self,
        /,
        method: str = "SUM_SQUARES_BETWEEN",
        *,
        var_of_obser: str = "",
        left_group: str = "",
        right_group: str = "",
        table_name: str = "",
        factoryrow: RowFactory = None,
        maxnumrows: int | None = 500,
        hints: list[str] | str | None = None,
        parallel: int | None = None,
    ) -> QueryRows:
        """
        One-way ANOVA (STATS_ONE_WAY_ANOVA), one result per value of var_of_obser.
        left_group: column with the groups; right_group: numeric column compared between groups.
        method: SUM_SQUARES_BETWEEN, SUM_SQUARES_WITHIN, DF_BETWEEN, DF_WITHIN,
        MEAN_SQUARES_BETWEEN, MEAN_SQUARES_WITHIN, F_RATIO or SIG.
        """
        if method not in (
            "SUM_SQUARES_BETWEEN",
            "SUM_SQUARES_WITHIN",
            "DF_BETWEEN",
            "DF_WITHIN",
            "MEAN_SQUARES_BETWEEN",
            "MEAN_SQUARES_WITHIN",
            "F_RATIO",
            "SIG",
        ):
            raise TypeError("Value type does not exists")
        if not var_of_obser or not left_group or not right_group:
            raise InvalidParameterException("var_of_obser, left_group and right_group must be defined")
        check_names(table_name)

        query = (
            f"{self._select(var_of_obser + ',', hints, parallel)} STATS_ONE_WAY_ANOVA({left_group}, {right_group}, '{method}') "
            f"FROM {table_name} GROUP BY {var_of_obser}"
        )
        return self._data_factory(factoryrow=factoryrow, query_string=query, maxnumrows=maxnumrows)
