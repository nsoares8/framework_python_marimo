from collections.abc import Callable
from typing import Any, final

import oracledb as oracle
import pandas as pd
import pyarrow as pa

from ..core import AsyncConnection, Connection
from ..utils.dataframe_types import dataframe_to_arrow
from ..utils.exception import InvalidParameterException
from ..utils.validation import check_names


class _ConnectorLoadMixin:
    """Data preparation shared by the sync and async connectors."""

    @staticmethod
    def _partition_data(partitions: dict[str, Any], columns: list[str] | None) -> tuple[list[str], dict[str, Any]]:
        """Columns and data per partition, ready for the loaders (DataFrames are converted to Arrow)."""
        if not partitions:
            raise InvalidParameterException("partitions must be defined")
        first = next(iter(partitions.values()))
        if isinstance(first, pd.DataFrame):
            columns = columns or first.columns.to_list()
        elif isinstance(first, pa.Table):
            columns = columns or first.column_names
        elif not columns:
            raise InvalidParameterException("columns must be defined when data is a list of tuples")
        data = {partition: dataframe_to_arrow(value[columns]) if isinstance(value, pd.DataFrame) else value
                for partition, value in partitions.items()}
        return columns, data


@final
class StoreWrapperSyncConnection(_ConnectorLoadMixin, Connection):

    def version(self):
        return self.__version__

    def get_connection(self) -> oracle.Connection:
        """ Open one database connection for manual operations. The caller must close it.
            Raise InvalidConnectionException, with the Oracle error, if it fails.

            >>> with WrapperConnection.create_connector().get_connection() as connection:
            ...     connection.cursor().execute("SELECT 1 FROM DUAL")
        """
        return self._get_connection()

    def bulk_load(self, table_name: str, data: Any, columns: list[str] | None = None,
                  batch_size: int | None = None, method: str = "auto") -> bool:
        """ Fast direct-path load into a new or staging table.
            data: pandas DataFrame (NaN/NaT become NULL), Arrow table, or list of tuples (then columns is required).
            method: "auto" (default), "direct_path" or "append_values" (see DataStore.load_into_database).
            The rows are committed by the load itself (no rollback) and the table is locked during the load.

            >>> WrapperConnection.create_connector().bulk_load("dw.stg_cdr", df, batch_size=100_000)
        """
        check_names(table_name)
        if isinstance(data, pd.DataFrame):
            columns = columns or data.columns.to_list()
            data = dataframe_to_arrow(data[columns])
        elif isinstance(data, pa.Table):
            columns = columns or data.column_names
        elif not columns:
            raise InvalidParameterException("columns must be defined when data is a list of tuples")
        return self._bulk_load(table_name, columns, data, batch_size, method)

    def bulk_load_partitions(self, table_name: str, partitions: dict[str, Any], columns: list[str] | None = None,
                             batch_size: int | None = None, workers: int = 4) -> dict[str, bool]:
        """ Load several partitions of the same table at the same time (see DataStore.load_partitions for why
            it exists). partitions: {partition name: DataFrame, Arrow table or list of tuples}.
            Returns {partition: True/False}; each partition is independent and committed block by block.

            >>> connector.bulk_load_partitions("dw.cdr_voz", {"P20261018": df_18, "P20261019": df_19}, workers=2)
        """
        check_names(table_name, *partitions)
        columns, data = self._partition_data(partitions, columns)
        return self._load_partitions(table_name, data, columns, batch_size, workers)

    def create_pool(self, _min: int = 1, _max: int = 10, increment: int = 1,
                    callback: Callable[..., Any] | None = None,
                    idle_timeout: int | None = None) -> oracle.ConnectionPool:
        """ Open a pool of connections. The caller must close it with pool.close().
            idle_timeout: seconds after which idle connections are closed by the pool (default: never).

            >>> pool = WrapperConnection.create_connector().create_pool(_max=5, idle_timeout=300)
            >>> with pool.acquire() as connection:
            ...     connection.cursor().execute("SELECT 1 FROM DUAL")
            >>> pool.close()
        """
        return oracle.create_pool(user=self.username, password=self.password, dsn=self.tns_dns,
                                  min=_min, max=_max, increment=increment, timeout=idle_timeout or 0,
                                  tcp_connect_timeout=self.timeout, config_dir=self.config,
                                  session_callback=callback)


@final
class StoreWrapperAsyncConnection(_ConnectorLoadMixin, AsyncConnection):

    def version(self):
        return self.__version__

    async def get_connection(self) -> oracle.AsyncConnection:
        """ Open one asynchronous database connection for manual operations. The caller must close it.
            Raise InvalidConnectionException, with the Oracle error, if it fails.

            >>> async with await WrapperConnection.create_connector(async_mode=True).get_connection() as connection:
            ...     await connection.run_pipeline(pipeline)
        """
        return await self._get_connection()

    async def bulk_load(self, table_name: str, data: Any, columns: list[str] | None = None,
                        batch_size: int | None = None, method: str = "auto") -> bool:
        """ Fast direct-path load into a new or staging table, e.g. before a pipeline that merges it.
            data: pandas DataFrame (NaN/NaT become NULL), Arrow table, or list of tuples (then columns is required).
            method: "auto" (default), "direct_path" or "append_values" (see DataStore.load_into_database).
            The rows are committed by the load itself (no rollback) and the table is locked during the load.

            >>> connector = WrapperConnection.create_connector(async_mode=True)
            >>> await connector.bulk_load("dw.stg_cdr", df, batch_size=100_000)
        """
        check_names(table_name)
        if isinstance(data, pd.DataFrame):
            columns = columns or data.columns.to_list()
            data = dataframe_to_arrow(data[columns])
        elif isinstance(data, pa.Table):
            columns = columns or data.column_names
        elif not columns:
            raise InvalidParameterException("columns must be defined when data is a list of tuples")
        return await self._bulk_load(table_name, columns, data, batch_size, method)

    async def bulk_load_partitions(self, table_name: str, partitions: dict[str, Any], columns: list[str] | None = None,
                             batch_size: int | None = None, workers: int = 4) -> dict[str, bool]:
        """ Load several partitions of the same table at the same time (see DataStore.load_partitions for why
            it exists). partitions: {partition name: DataFrame, Arrow table or list of tuples}.
            Returns {partition: True/False}; each partition is independent and committed block by block.

            >>> await connector.bulk_load_partitions("dw.cdr_voz", {"P20261018": df_18, "P20261019": df_19}, workers=2)
        """
        check_names(table_name, *partitions)
        columns, data = self._partition_data(partitions, columns)
        return await self._load_partitions(table_name, data, columns, batch_size, workers)

    def create_pool(self, _min: int = 1, _max: int = 10, increment: int = 1,
                    callback: Callable[..., Any] | None = None,
                    idle_timeout: int | None = None) -> oracle.AsyncConnectionPool:
        """ Open a pool of asynchronous connections. The caller must close it with await pool.close().
            idle_timeout: seconds after which idle connections are closed by the pool (default: never).

            >>> connector = WrapperConnection.create_connector(async_mode=True)
            >>> pool = connector.create_pool(_max=5, idle_timeout=300)
            >>> results = await PipelineOperational(connector).run_pipeline_async(pipeline, pool=pool)
            >>> await pool.close()
        """
        return oracle.create_pool_async(user=self.username, password=self.password, dsn=self.tns_dns,
                                        min=_min, max=_max, increment=increment, timeout=idle_timeout or 0,
                                        tcp_connect_timeout=self.timeout, config_dir=self.config,
                                        session_callback=callback)
