from typing import Any, Literal, overload

from .connections import StoreWrapperAsyncConnection, StoreWrapperSyncConnection


class WrapperConnection:

    @overload
    @classmethod
    def create_connector(cls, *, async_mode: Literal[False] = False, **kwargs: Any) -> StoreWrapperSyncConnection: ...

    @overload
    @classmethod
    def create_connector(cls, *, async_mode: Literal[True], **kwargs: Any) -> StoreWrapperAsyncConnection: ...

    @classmethod
    def create_connector(cls, *, async_mode: bool = False,
                         **kwargs: Any) -> StoreWrapperSyncConnection | StoreWrapperAsyncConnection:
        """ Create a connector for manual operations (e.g. pipelines), outside the DataStore.
            The connector only holds the configuration; nothing is opened in Oracle until
            get_connection() (one connection) or create_pool() (several) is called.
            Parameters not passed default to the environment variables.
            Pipelines need async_mode=True.

            >>> connector = WrapperConnection.create_connector(async_mode=True)
            >>> pool = connector.create_pool(_max=5)
        """
        if async_mode:
            return StoreWrapperAsyncConnection(**kwargs)
        return StoreWrapperSyncConnection(**kwargs)

    @overload
    @classmethod
    def create_connection(cls, *, async_mode: Literal[False] = False, **kwargs: Any) -> StoreWrapperSyncConnection: ...

    @overload
    @classmethod
    def create_connection(cls, *, async_mode: Literal[True], **kwargs: Any) -> StoreWrapperAsyncConnection: ...

    @classmethod
    def create_connection(cls, *, async_mode: bool = False,
                          **kwargs: Any) -> StoreWrapperSyncConnection | StoreWrapperAsyncConnection:
        """ Old name of create_connector, kept for compatibility. Use create_connector. """
        return cls.create_connector(async_mode=async_mode, **kwargs)
